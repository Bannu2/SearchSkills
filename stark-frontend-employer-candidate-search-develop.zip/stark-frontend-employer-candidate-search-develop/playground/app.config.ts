interface AppConfigInput {
    appName: string
    searchSkillURL: string
    candidateSearchURL: string
    rolesURL: string
    citiesURL: string
    departmentsURL: string
    globalSearchURL: string
    notesURL: string
    tasksURL: string
    assesmentHistoryURL: string
    badgesURL: string
    tagsURL: string
    jobApplicantsURL: string
    jobsURL: string
    api: object
    transactionalMail: string
    emailTemplatesURL: string
    userPluginsURL: string
    assetsURL: string
    ai: object
    videoURL: string
    candidatesURL: string
    domainUsersGetURL: string
    recommendationsURL: string
}

const defineAppConfig: AppConfigInput = {
    appName: 'stark.ai',
    assetsURL: 'https://assets.infinity-api.net/',
    searchSkillURL: 'https://api.stark.ai/prod/orm/public/skills/1',
    rolesURL: 'https://api.stark.ai/prod/orm/public/job_roles/1',
    citiesURL: 'https://api.stark.ai/prod/orm/public/cities/1',
    departmentsURL: 'https://api.stark.ai/prod/orm/public/departments/1',
    globalSearchURL: 'https://api.stark.ai/prod/search-elastic/search/{{indexes}}?query={{input}}&limit=5',
    candidateSearchURL: 'https://backend-core-search-elastic.mercury.infinity-api.net/api/v66/search/stark/candidates',
    notesURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/notes',
    assesmentHistoryURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/responses',
    badgesURL: 'https://api.stark.ai/prod/orm/public',
    tagsURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/tags',
    tasksURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/tasks',
    jobApplicantsURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/job_applicants',
    candidatesURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/candidates',
    jobsURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/jobs',
    api: {
        twilio: {
            url: 'https://backend-twilio.mercury.infinity-api.net/api/v21/twilio/',
            voiceURL: 'https://backend-twilio.mercury.infinity-api.net/api/v21/twilio/voice',
        },
    },
    recommendationsURL: 'https://api.stark.ai/prod/orm/recommendations/{id}',
    emailTemplatesURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/email_templates',
    transactionalMail: 'https://backend-core-app-mail.mercury.infinity-api.net/api/v22/mail/app/transactional',
    userPluginsURL: 'https://orm-talentx.mercury.infinity-api.net/api/v130/user-plugins/user_plugins/',
    ai: {
        textGenerationOpenAI: 'https://backend-core-ai-content.mercury.infinity-api.net/api/v10/ai/openai/text',
        apiKey: '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',
    },
    videoURL: 'https://api.stark.ai/prod/orm/public/intro',
    domainUsersGetURL: ' https://backend-core-auth-service.mercury.infinity-api.net/api/v111/users',
}
export default defineAppConfig
