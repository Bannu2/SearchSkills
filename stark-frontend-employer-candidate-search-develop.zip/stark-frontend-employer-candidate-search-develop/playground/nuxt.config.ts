export default defineNuxtConfig({
    modules: ['../src/module', '@nuxtjs/tailwindcss', '@nuxt/image', '@bub-io/frontend-plugin-ai-prompt'],
    devtools: { enabled: true },
    tailwindcss: {
        content: ['./components/**/*.{js,vue,ts}', './pages/**/*.vue', './data/**/*.{js,ts,json}', './pages/**/*.vue', './utils/**/*.{js,ts,json}'],
    },
    postcss: {
        plugins: {
            tailwindcss: {},
            autoprefixer: {},
        },
    },
    css: ['~/assets/main.css', '@fortawesome/fontawesome-svg-core/styles.css'],
    app: {
        head: {
            title: 'stark.ai',
            htmlAttrs: {
                lang: 'en',
            },
            meta: [
                { name: 'description', content: 'Your Personal Recruiter' },
                {
                    name: 'viewport',
                    content: 'width=device-width,initial-scale=1',
                },
                {
                    name: 'theme-color',
                    content: '#000000',
                },
            ],
            // Font Family
            link: [
                {
                    rel: 'preload stylesheet',
                    type: 'text/css',
                    as: 'style',
                    crossorigin: 'anonymous',
                    href: 'https://rsms.me/inter/inter.css',
                },
                {
                    rel: 'preload stylesheet',
                    type: 'text/css',
                    as: 'style',
                    crossorigin: 'anonymous',
                    href: 'https://kit.fontawesome.com/16d7faf68e.css',
                },
            ],
        },
    },
    build: {
        transpile: ['@fortawesome/vue-fontawesome'],
    },
})
