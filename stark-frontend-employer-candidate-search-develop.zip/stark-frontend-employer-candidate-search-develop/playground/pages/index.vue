<template>
    <div>
        <CandidateMain />
    </div>
</template>

<script setup lang="ts"></script>
