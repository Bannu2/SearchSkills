<template>
    <div>
        <CandidateCards />
    </div>
</template>

<script setup lang="ts"></script>
