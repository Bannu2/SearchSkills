<template>
    <div>
        <ModalImport />
        <ModalUpload />
        <ModalPreview />
        <FormsModalForm />
        <Alert />
        <ClientOnly>
            <EmailMain />
        </ClientOnly>
        <Notification />
        <AIGenerateContent />
        <Alert />
        <NuxtPage>
            <slot></slot>
        </NuxtPage>
    </div>
</template>

<script setup lang="ts"></script>
