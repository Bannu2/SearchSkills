<template>
    <div>
        <TaskSummary entity="CANDIDATES" :entity-id="props.tasks"></TaskSummary>
    </div>
</template>
<script setup lang="ts">
interface Props {
    tasks: String
}
const props = withDefaults(defineProps<Props>(), {})
</script>
