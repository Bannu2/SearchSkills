<template>
    <div class="flex items-center justify-center">
        <div class="flex gap-2 mr-3">
            <div v-for="tag in tags.slice(0, 2)" :key="tag" class="group relative">
                <div>
                    <div class="flex items-center justify-center">
                        <span class="cursor-pointer hover:text-skin-primary px-3 py-2.5 text-[12px] text-base text-white"> <font-awesome-icon :icon="['fad', 'tag']" /> {{ tag }}</span>
                    </div>
                </div>
            </div>
            <!-- Start of display of networks in menu -->
            <Menu v-if="tags.length > 2" as="div" class="relative inline-block text-left">
                <div class="mt-4">
                    <!-- Start of menu button -->
                    <MenuButton class="flex items-center justify-center w-5 h-5 text-base text-white"><i class="fa-regular fa-ellipsis text-lg"></i></MenuButton>
                    <!-- End of menu button -->
                </div>

                <transition
                    enter-active-class="transition duration-100 ease-out"
                    enter-from-class="transform scale-95 opacity-0"
                    enter-to-class="transform scale-100 opacity-100"
                    leave-active-class="transition duration-75 ease-in"
                    leave-from-class="transform scale-100 opacity-100"
                    leave-to-class="transform scale-95 opacity-0"
                >
                    <!-- Start of menu items -->
                    <MenuItems
                        as="div"
                        class="absolute right-0 mt-2 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black ring-opacity-5 w-[105px] focus:outline-none"
                    >
                        <div class="px-1 py-1">
                            <!-- Start of menu item -->
                            <MenuItem v-for="tag in tags.slice(2, Infinity)" v-slot="{}" :key="tag" as="div">
                                <div>
                                    <div class="text-skin-base hover:text-skin-primary px-3 py-2.5 text-[12px] border-r border-skin-base/10 cursor-pointer">
                                        <font-awesome-icon :icon="['fad', 'tag']" class="mr-1" /> {{ tag }}
                                    </div>
                                </div>
                            </MenuItem>
                            <!-- End of menu item -->
                        </div>
                    </MenuItems>
                    <!-- End of menu items -->
                </transition>
            </Menu>
            <!-- End of display of networks in menu -->
        </div>

        <!-- Start of add tag button -->
        <div>
            <button
                type="button"
                class="inline-flex items-center gap-x-1.5 rounded-md px-2.5 py-1.5 text-sm font-medium text-skin-white shadow-smfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2"
                @click="(open = true), (tagName = '')"
            >
                <font-awesome-icon :icon="['far', 'plus']" />
                Add Tag
            </button>
        </div>
        <!-- End of add tag button -->

        <!-- Start of tags -->
        <div
            class="[&_.slider-input]:w-full filter [&_.slider-input]:px-3 [&_.input-field.relative]:items-center [&_.input-field.relative]:flex-row-reverse [&_.input-field.relative]:justify-end [&_.input-field.relative]:gap-x-4 [&_.input-field.relative]:flex [&_.input-field.relative_label]:mb-0 mb-2"
        >
            <FormsBasicForm :key="render" :schema="basicSearchForm" />
        </div>
        <!-- End of tags -->

        <!-- Start of add tag modal -->
        <Modal :open="open" type="modal" size="xs" @hide="open = false">
            <template #title>Add Tag</template>
            <template #body>
                <div class="mt-2">
                    <input
                        id="name"
                        v-model="tagName"
                        type="text"
                        name="text"
                        class="block w-full rounded-md border-0 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm sm:leading-6 p-2"
                        placeholder="Enter tag name"
                    />
                </div>
            </template>
            <template #ok>
                <button @click="saveTag">Save</button>
            </template>
            <template #cancel>Cancel</template>
        </Modal>
        <!-- End of add tag modal -->
    </div>
</template>
<script lang="ts" setup>
import { onMounted, ref } from 'vue'
import { Menu, MenuButton, MenuItems, MenuItem } from '@headlessui/vue'
import { useAuthLazyFetch, useAuthLazyFetchPost, useHandlebars } from '#imports'
import basicSearchForm from '~~/data/tags.json'

const open = ref(false)
const tagName = ref('')
const render = ref(0)
const tags = ref([])

const props = defineProps({
    // eslint-disable-next-line vue/require-default-prop
    cardData: {
        type: Object,
    },
})

onMounted(() => {
    setTimeout(async () => {
        const { data: response } = await useAuthLazyFetch(
            useHandlebars(`{{tagsURL}}?visibility_status=company&sort_column=id&sort_direction=desc&offset=0&limit=100&filters=%5B%7B%22project_id%22%3A%22${props.cardData.uid}%22%7D%5D`),
            {},
        )
        tags.value = response.value.map((item: any) => item.name)
    }, 1000)
})

// Save newly added tag
const saveTag = async () => {
    await useAuthLazyFetchPost(useHandlebars('{{ tagsURL }}'), {
        body: {
            project_id: props.cardData.uid,
            name: tagName.value,
            entity: 'CANDIDATES',
        },
    })
    render.value++
}
</script>
