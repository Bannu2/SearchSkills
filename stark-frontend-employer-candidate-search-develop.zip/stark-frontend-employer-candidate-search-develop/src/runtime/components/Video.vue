<template>
    <div
        v-if="cards && cards?.questions"
        class="border border-skin-base/10 job-feature-card rounded-md bg-skin-white p-4 mb-3 space-y-3 max-h-[300px] overflow-auto scrollbar-thin scrollbar-thumb-[#6666664f]"
    >
        <video class="max-h-[430px] w-full overflow-hidden object-cover rounded-t-md" controls>
            <source :src="cards?.questions[0]?.response_url" />
        </video>
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useAuthLazyFetch, useHandlebars } from '#imports'
const cards = ref()
interface Props {
    video: String
}
const props = withDefaults(defineProps<Props>(), {})
onMounted(() => {
    setTimeout(() => {
        getVideoData()
    }, 100)
})

const getVideoData = async () => {
    const { data: response } = await useAuthLazyFetch(
        useHandlebars(`{{ videoURL }}?profile_uid=${props.video}`),

        {},
    )

    cards.value = response.value
}
</script>
