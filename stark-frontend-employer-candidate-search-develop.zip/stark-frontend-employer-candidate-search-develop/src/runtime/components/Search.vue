<template>
    <div>
        <!-- Loading section -->
        <div v-if="isLoading">
            <LogoLoading />
        </div>

        <!-- Start of search data -->
        <div v-if="hideSearchData">
            <div class="border p-6 rounded-xl bg-skin-white mx-auto main-search-section">
                <div class="mb-5">
                    <!-- Search heading and description -->
                    <h3 class="mb-0 font-semibold leading-[1.4] search-heading text-skin-base text-[1.27rem]">Search candidates for the job</h3>
                    <p class="text-[15.5px] text-skin-secondary/70 search-description">Stark will automatically find the skills and auto search</p>
                </div>

                <!--Start of form fields for search -->
                <div>
                    <!-- Multi-select field -->
                    <FormsFieldsMultiSelect
                        class="[&_.multiselect]:h-12 [&_.multiselect-tags-search]:pl-1 [&_.multiselect-placeholder]:h-[unset] [&_.multiselect-placeholder]:top-[12px] [&_.multiselect-tag]:bg-skin-base/5 [&_.multiselect-tag]:text-skin-base [&_.multiselect-tag]:font-normal [&_.multiselect-tag_span]:!text-[13px]"
                        :schema="jobsSchema"
                        @input="input"
                        @select="(value, option) => onSelect(option)"
                        @remove="(value, option) => onSelect(option)"
                        @deselect="(value, option) => onSelect(option)"
                    >
                        <template #option="{ option }">
                            <!-- Custom template for each option -->
                            <div v-if="option?.key?.length" class="flex justify-between items-center px-4 py-2">
                                <span class="uppercase"> {{ option.key?.slice(0, -1) }} </span> <span class="pl-2 font-semibold custom-span">{{ option.name }}</span>
                            </div>
                        </template>
                    </FormsFieldsMultiSelect>
                    <div class="flex items-start mt-4 justify-end">
                        <!-- Buttons for advanced search and basic search -->
                        <div class="flex items-center gap-x-3">
                            <button
                                type="button"
                                class="bg-skin-white px-6 py-2.5 flex items-center gap-x-2 text-skin-base font-medium text-sm capitalize rounded-md search-button hover:bg-skin-base/90 border-skin-base border hover:text-skin-white"
                                @click="openAdvance"
                            >
                                Advanced search
                            </button>
                            <button
                                type="button"
                                class="bg-[#ffd819] px-6 py-2.5 flex items-center gap-x-2 text-skin-base font-medium text-sm capitalize rounded-md search-button hover:bg-[#ffd819a6]"
                                @click="candidateSearchCall"
                            >
                                <font-awesome-icon :icon="['far', 'magnifying-glass']" />
                                search
                            </button>
                        </div>
                    </div>
                </div>
                <!--End of form fields for search -->
            </div>

            <!-- Advanced Search section -->
            <div v-if="displayAdvancedSearch" class="border p-6 rounded-xl mt-4 bg-skin-white mx-auto max-w-7xl advanced-search-section">
                <CandidateAdvancedSearch @search-data="searchData" @prefill-data="prefillSkill" />
            </div>
        </div>
        <!-- End of search data -->

        <!-- Candidate cards section -->
        <div v-if="showCandidateCardsData" class="overflow-auto">
            <div class="py-5 bg-skin-white px-[1rem] flex gap-x-4 items-center">
                <button
                    type="button"
                    class="px-3 py-2.5 group rounded-md border border-gray-200 !shadow-none text-skin-white hover:bg-skin-primary/90 text-sm hover:transition-all font-medium flex items-center gap-1.5 hover:border-transparent"
                    @click="SearchSkill"
                >
                    <font-awesome-icon :icon="['far', 'arrow-left']" class="text-[16px] text-neutral-800 group-hover:text-white" />
                </button>
                <div class="candidate-header">
                    <h3 class="mb-[3px] font-semibold leading-[1.4] search-heading text-skin-base text-lg">Featured Stark Candidates</h3>
                    <p class="text-sm text-skin-secondary/70 search-description">Stark connects you directly with candidates and Helps you schedule an interview instantly</p>
                </div>
            </div>

            <!-- Candidate filter and cards display -->
            <div class="flex flex-nowrap gap-x-3 h-full pr-[1rem]">
                <!-- Candidate filter section -->
                <div class="w-[20rem] bg-skin-white sticky top-0 border shadow-sm max-h-screen shrink-0">
                    <CandidateFilter :prefill-skill="prefillSkillData" @search-data="searchFilterData" />
                </div>

                <!-- Candidate cards section -->
                <div class="grow">
                    <CandidateCards :key="render" :response="candidateSearchResults" @scroll="loadMoreRecords" />
                </div>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { ref } from 'vue'
import { useAuthLazyFetchPost, useHandlebars, useShowNoty } from '#imports'
const job: any = ref()
const displayAdvancedSearch = ref(false)
const showCandidateCardsData = ref(false)
const hideSearchData = ref(true)
const candidateSearchResults = ref([])
const render = ref(0)
const userSearchInput = ref()
const limit = ref(10)
const offset = ref(0)
const isLoading = ref(false)

// Schema for jobs multi-select field
const jobsSchema = {
    key: 'skills',
    name: 'Skills',
    type: 'auto_complete',
    options_key: 'name',
    options_label: 'name',
    searchable: true,
    track_by: 'name',
    placeholder: 'Search Skills',
    close_on_select: false,
    url: '{{searchSkillURL}}?name={{input}}&is_cached=true&sort_column=name&sort_direction=asc&offset=0&limit=100&search=%5B%7B%22name%22%3A%7B%22value%22%3A%22{{input}}%22%2C%22condition%22%3A%22like_prefix%22%7D%7D%5D',
    options: [],
    divClass: 'col-span-4',
    class: '',
    helpText: 'Search candidates by the key skills',
}
const prefillSkillData = ref()
// Manage multi-select input and transform it for tags
const input = (data: any) => {
    job.value = data
    prefillSkillData.value = { skills: data.textValue.split(',') }
}
const SearchSkill = () => {
    // Resetting visibility flags to go back to search skill section
    showCandidateCardsData.value = false
    displayAdvancedSearch.value = false
    hideSearchData.value = true
}

// Function to handle search data
const searchData = (data: any) => {
    candidateSearchResults.value = data
    if (candidateSearchResults.value) {
        showCandidateCardsData.value = true
        hideSearchData.value = false
    }
}

// Function to toggle display of advanced search
const openAdvance = () => {
    displayAdvancedSearch.value = !displayAdvancedSearch.value
}
const emits = defineEmits(['search-data'])

const requestBody = ref({})

const candidateSearchCall = () => {
    const skill = job.value && job.value.textValue !== undefined ? job.value.textValue : ''
    // Check if a skill is selected before triggering the search
    if (skill === '') {
        useShowNoty('error', 'Please specify a skill')
        return // Returning here to exit the function if no skill is selected
    }
    requestBody.value = {
        skill,
        job_location: [],
        current_designation: [],
        currently_working: '',
        notice_period: 'Immediately',
        total_experience: {
            min: 0,
            max: 0,
        },
        salary: {
            min: 0,
            max: 0,
        },
    }
    candidateSearch()
}

// Function to trigger candidate search
const candidateSearch = async () => {
    // Set loading state
    isLoading.value = true

    // Make a POST request to search candidates
    const { data: response } = await useAuthLazyFetchPost(useHandlebars('{{ candidateSearchURL }}?query_type=search&limit={{limit}}&offset={{offset}}', { limit: limit.value, offset: offset.value }), {
        body: requestBody.value,
    })

    // Process response data
    if (response.value) {
        // Add new results to existing candidateSearchResults
        candidateSearchResults.value.push(...response.value)
        isLoading.value = false
        showCandidateCardsData.value = true
        hideSearchData.value = false
        emits('search-data', userSearchInput.value)
    }
}

// Function to load more records for pagination
const loadMoreRecords = (data: any) => {
    if (data) {
        offset.value += limit.value
        candidateSearch()
    }
}

// Function to handle search filter data
const searchFilterData = (data: any) => {
    requestBody.value = data
    candidateSearchResults.value = []
    offset.value = 0
    candidateSearch()
    render.value += 1
}

const prefillSkill = (data: any) => {
    prefillSkillData.value = data
}
</script>
<style>
.multiselect-tags-search:focus {
    border-color: transparent !important;
}
.multiselect-tags-search:focus,
body .multiselect.is-active {
    box-shadow: none !important;
}

.multiselect-dropdown::-webkit-scrollbar {
    height: 5px;
    width: 5px;
}
.multiselect-dropdown li {
    font-size: 14px;
    padding: 8px 16px;
}
.multiselect-dropdown li .mt-1 {
    margin-left: 0;
    margin-top: 0 !important;
}
.checkbox {
    box-shadow: none !important;
    cursor: pointer;
}
.form .vue-tel-input:focus-within {
    height: 46px !important;
}
input:focus,
select:focus {
    box-shadow: none !important;
}
::-webkit-calendar-picker-indicator,
::-webkit-datetime-edit {
    cursor: pointer !important;
}
.multiselect-dropdown {
    z-index: 2;
}
form .mb-2.relative {
    margin-bottom: 0 !important;
}
.multiselect-caret {
    z-index: 0;
}
.multiselect-option {
    font-size: 14px;
    padding: 8px;
}
.multiselect-clear {
    z-index: 0;
}
.multiselect-dropdown ul li .uppercase {
    font-size: 10px;
    background-color: #fbf3e8 !important;
    letter-spacing: 0.2px;
    padding: 2px 8px !important;
    text-transform: capitalize;
    color: #606060 !important;
    border-radius: 6px !important;
    line-height: 13px;
    margin-left: 10px;
}
.multiselect-dropdown ul li > div {
    display: flex;
    flex-direction: row-reverse;
}
.candidates-filter .input-field.relative {
    column-gap: 0;
}
</style>
