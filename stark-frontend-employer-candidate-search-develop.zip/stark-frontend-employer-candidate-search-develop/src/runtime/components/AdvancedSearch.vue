<template>
    <!-- Start of search database -->
    <div>
        <div class="mb-5">
            <h3 class="mb-0 font-semibold leading-[1.4] search-heading text-skin-base text-[1.25rem]">Search Database</h3>
            <p class="text-[15px] text-skin-secondary/70 search-description">Explore our extensive database of 2 million candidates to discover the ideal match for your job.</p>
        </div>
        <div
            class="advance-search rounded-t-xl border-skin-base/40 candidate-search border-b-0 bg-skin-white border transition-all duration-500 [&_.col-span-8]:col-span-8 [&_.col-span-3]:col-span-3 [&_.col-span-2]:col-apn-2 [&_.mb-2.relative]:mb-0 [&_label]:hidden [&_ul_li]:p-[8px_16px] [&_.multiselect-tags-search]:h-[22px] [&_.multiselect-tags]:mt-0 [&_.bar_.bar-left]:bg-skin-base/5 [&_.zero-ranage-margin]:p-0 [&_.multiselect-tags-search>::placeholder]:text-skin-muted [&_button.relative]:mt-[2px] lg:[&_.bar-left]:!py-[4px] md:[&_.bar-left]:!py-[3px][&_.grid]:block md:[&_.grid]:grid md:[&_.col-span-6_.slider-input_label]:top-[3px] [&_.col-span-6_.slider-input_label]:top-[11px] [&_.py-2.border-t_.col-span-4_.mb-2.relative]:border-b md:[&_.py-2.border-t_.col-span-4_.mb-2.relative]:border-b-0 [&_.multi-range-slider-bar-only.zero-ranage-margin_.thumb.thumb-right]:!left-[-8px] [&_.multiselect::after]:hidden [&_.multiselect-tags-search-wrapper]:!ml-0 [&_.multiselect-option.is-pointed]:!bg-skin-base/10 [&_.multiselect-option.is-selected]:!bg-skin-base/10 [&_.multiselect-option_.flex]:!p-0 [&_.multiselect-tag.is-user]:!border-0 [&_.multiselect-tag.is-user]:!text-sm [&_.multiselect-tag.is-user]:!font-normal [&_.multiselect-single-label-text]:!font-normal [&_.multiselect-single-label-text]:!text-sm [&_.multiselect-single-label-text]:!text-skin-base [&_.slider-input_label]:text-base [&_.slider-input_label]:font-normal [&_.slider-input_label]:text-skin-base [&_.multiselect-option_.custom-span]:!font-normal [&_.multiselect-option_.custom-span]:!text-sm [&_.multi-range-slider-bar-only.zero-ranage-margin_.thumb-left]:right-0 [&_.grid.grid-cols-1.gap-x-6.gap-y-4>.cols-span-4:first-child]:!border-l-0 [&_.slider-input]:relative [&_ul_li.is-pointed]:bg-skin-base/5 motion-reduce:transition-none"
        >
            <!-- Start of Basic search form-->
            <FormsBasicForm :schema="basicSearchForm" :default-values="{ ...form }" @blur="update" @input="update" />
            <!-- End of Basic search form -->
        </div>
    </div>
    <div class="flex items-start mt-4 justify-between">
        <!-- Start of display premimum candidates -->
        <div class="bg-yellow-50 gap-x-3 py-2 px-3.5 items-center rounded-md border border-yellow-200 flex">
            <input name="comments" type="checkbox" class="w-5 h-5 border-skin-base/10 border cursor-pointer" />
            <div class="leading-3">
                <label class="pb-0.5 block text-sm text-skin-base font-medium">Premimum Candidates</label>
                <small class="text-xs text-skin-muted block">Candidates who have earned badges and with personality traits</small>
            </div>
        </div>
        <!-- End of display premimum candidates -->
        <button
            type="button"
            class="bg-skin-primary px-6 py-2.5 flex items-center gap-x-2 text-skin-white font-medium text-sm capitalize rounded-md search-button hover:bg-skin-primary/90"
            @click="search"
        >
            <font-awesome-icon :icon="['far', 'magnifying-glass']" />
            Search
        </button>
    </div>

    <div v-if="display === 'tabs'" :key="render">
        <CandidateCards :response="data" />
    </div>
    <!-- End of search database -->
</template>
<script setup lang="ts">
import { ref } from 'vue'
import { useAuthLazyFetchPost, useHandlebars, useBusEmit } from '#imports'
import basicSearchForm from '~~/data/candidate-search.json'

const searchData: any = ref([])
const display = ref('input')
const data = ref()
const render = ref(false)

const emits = defineEmits(['search-data', 'prefill-data'])

// Function to update search data and emit bus event
const update = (searchItem: any) => {
    searchData.value = searchItem
    emits('prefill-data', searchItem)
    useBusEmit('candidate-advanced-search', searchData.value?.skills || '')
}

// Function to perform search
const search = async () => {
    const gender = searchData?.value?.gender
    const { data: response } = await useAuthLazyFetchPost(useHandlebars('{{ candidateSearchURL }}?query_type=search&limit=100'), {
        body: {
            skill: searchData.value?.skills || '',
            job_location: searchData.value?.city || [],
            current_designation: searchData.value?.role ? [searchData.value?.role] : [],
            currently_working: searchData.value?.currently_working || '',
            notice_period: searchData.value?.notice_period || 'Immediately',
            total_experience: {
                min: searchData?.value?.search_details?.experience[0],
                max: searchData?.value?.search_details?.experience[1],
            },
            department: searchData.value?.departments || '',
            language: searchData?.value?.languages_known?.[0] || '',
            institute: searchData?.value?.institutions?.[0] || '',
            degree: searchData?.value?.education?.[0] || '',
            job_type: searchData?.value?.job_type || '',
            salary: {
                min: searchData?.value?.search_details?.salary[0],
                max: searchData?.value?.search_details?.salary[1],
            },
            ...(gender && { gender }),
        },
    })
    if (response.value) {
        data.value = response.value
        emits('search-data', data.value)
        display.value = 'tabs'
        render.value += 1
    }
}
</script>
<style>
.candidate-search [for='cities'],
.candidate-search [for='job_roles'],
.candidate-search [for='Skills'] {
    @apply hidden;
}
.advance-search .grid.grid-cols-1.gap-x-6.gap-y-4 {
    @apply grid-cols-12 gap-0 divide-x-[0.12rem] divide-skin-base/10;
}
.advance-search .col-span-4 {
    @apply border-b-[0.12rem]  !border-skin-base/10;
}
.advance-search .col-span-4:nth-child(14) .multiselect {
    @apply !rounded-bl-xl;
}
.advance-search .col-span-4:nth-child(14) {
    @apply !border-b-0 !rounded-bl-xl;
}
.advance-search .col-span-4:nth-child(14),
.advance-search .col-span-4:nth-child(11),
.advance-search .col-span-4:nth-child(7),
.advance-search .col-span-4:nth-child(4),
.advance-search .col-span-4:first-child {
    @apply !border-l-0;
}
.advance-search .slider-input {
    @apply h-full flex flex-col justify-center;
}
.advance-search .mt-1.text-xs.leading-6 {
    @apply pl-2.5 text-[11px];
}
.advance-search .switch-toggle {
    @apply mb-0 flex flex-row-reverse  gap-x-4 justify-end mt-2  pl-5 pr-5;
}
.advance-search .switch-toggle_label {
    @apply mb-0 font-medium  text-skin-base  block  capitalize;
}
.advance-search .multiselect-single-label {
    @apply !bg-skin-base/10  !rounded-sm  !h-[26px]  mt-2 !px-3 !py-1;
}
.advance-search .multiselect-tag {
    @apply font-normal  !mb-[2px] !px-2  !bg-skin-base/5;
}
.advance-search input.input-block {
    @apply border-0 p-[6px_18px] ring-0 shadow-none;
}
.advance-search input.input-block:focus {
    @apply outline-0;
}
.advance-search ul_li_.ml-2.mt-1 {
    @apply mt-0 ml-0 font-sans text-skin-base;
}
.advance-search .multiselect-dropdown {
    @apply !rounded-none bottom-0 bg-skin-white !z-40;
}
.advance-search .multiselect::after {
    @apply absolute h-[26px] w-[26px] bg-skin-primary/10 right-[12px]  top-[7px] rounded-full;
}
.advance-search .multiselect.is-active {
    @apply border-0 border-0 shadow-none shadow-none;
}
.advance-search .multiselect.is-active:focus {
    @apply border-0;
}
.advance-search .col-span-8_.mb-2.relative {
    @apply border-b md:border-0;
}
.advance-search .multiselect-caret {
    @apply bg-skin-primary  rounded-full  mr-[9px] md:mb-[0px]  mb-[9px] h-[13px];
}
.advance-search .multiselect-option {
    @apply !text-sm !py-2  !px-5;
}
.advance-search .multiselect-option_.text-gray-600 {
    @apply !italic  !text-skin-base/50  !ml-1 !text-xs;
}
.advance-search .thumb::before {
    @apply lg:!w-5 lg:!h-5 !w-4 !h-4 !top-[3px] lg:!top-[1px];
}
.advance-search .multiselect {
    @apply p-[5px_20px_5px_20px] md:p-[9px_16px] !pt-2 border-0 !rounded-tl-xl !rounded-tr-xl;
}
.advance-search .col-span-6 {
    @apply !border-l-0 md:!border-l-2;
}
.advance-search .slider-input {
    @apply w-full pr-6 md:py-3 py-5;
}
.advance-search .col-span-4 .slider-input label {
    @apply block left-[15px] absolute top-[18px] text-sm md:text-[15px];
}
.advance-search .multiselect-placeholder {
    @apply text-sm lg:text-[15px] text-skin-base font-normal pl-0;
}
.advance-search .input-field.relative label,
.advance-search .input-field.relative label span {
    @apply block mb-0 !text-sm md:!text-[15px] !text-skin-base !font-normal;
}
.advance-search .input-field.relative {
    @apply w-full px-5 flex items-center;
}
.advance-search .col-span-4:nth-child(6),
.advance-search .col-span-4:nth-child(5) {
    @apply flex flex-col justify-center items-center;
}
.advance-search .input-field.relative [type='checkbox'] {
    @apply w-[22px] h-[22px] ml-3 border;
}
.advance-search .multiselect-option.is-selected {
    @apply !text-skin-base;
}
</style>
