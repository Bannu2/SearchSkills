<template>
    <div class="comment-employer">
        <h5 class="text-[15px] font-medium text-neutral-900 mb-3 flex items-center">
            <font-awesome-icon :icon="['far', 'message-lines']" class="text-[#3e3e3e] text-[17px] mr-2 mt-[2px]" /><span>Employer Comments</span>
        </h5>
        <div v-if="comments && comments.length" class="divide-y divide-skin-base/10 divide-dashed candidate-analysis">
            <div class="">
                <ul role="list" class="grid grid-cols-12 flex-wrap justify-between gap-x-2">
                    <li v-for="job in comments" :key="job" class="p-3 border border-skin-base/5 divide-y divide-skin-base/10 rounded-md col-span-6 grow mb-2">
                        <div class="text-[13px] text-neutral-900 space-y-1">
                            <div class="flex gap-2.5">
                                <div class="employer-comment bg-gray-50 flex items-center justify-center rounded-full">
                                    <font-awesome-icon :icon="['far', 'user']" class="text-[13px] text-neutral-600" />
                                </div>
                                <div>
                                    <p class="text-[13px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">{{ job.requester_name }} ({{ job.designation }}) - {{ job.company_name }}</p>
                                    <p class="text-[12px] text-gray-500 line-clamp-3 first-letter:capitalize mb-[5px]">
                                        {{ job.description }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div v-else class="my-5">
            <div class="flex flex-col items-center justify-center">
                <img src="https://assets.infinity-api.net/emc2/stark-recruiter/empty-state/no-results-found.svg" alt="" class="w-auto h-[120px] mx-auto object-cover" />
                <span class="font-medium text-sm text-neutral-900">No Comments Found</span>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useAppConfig, useAuthLazyFetch } from '#imports'

const comments = ref()

interface Props {
    candidateId: String
}
const props = withDefaults(defineProps<Props>(), {})

onMounted(() => {
    setTimeout(() => {
        getComments()
    }, 0)
})

const getComments = async () => {
    const { data: response } = await useAuthLazyFetch(`${useAppConfig().recommendationsURL}?profile_id=${props.candidateId}&offset=0&limit=10&sort_column=id&sort_direction=desc`, {})
    comments.value = response.value
}
</script>
