<template>
    <div class="card-container bg-skin-white pb-[80px] scrollbar-thin scrollbar-thumb-[#6666664f] candidates-filter">
        <!--Start of filters section -->
        <div class="flex border-b border-dashed justify-between py-2.5 px-4 items-center scrollbar-">
            <h2 class="mb-0 text-lg font-semibold text-skin-base">Filters</h2>
            <div class="flex gap-x-2">
                <!-- Reset button -->
                <button class="border px-2 py-1 rounded-md text-skin-base hover:text-skin-primary hover:border-skin-primary" @click="clear('reset')">
                    <span>
                        <font-awesome-icon :icon="['far', 'fa-rotate']" />
                    </span>
                </button>
                <!-- Search button -->
                <button
                    class="px-3 py-1 rounded-md bg-[#ffd819] text-skin-base !shadow-none hover:bg-[#ffd819a6] text-sm hover:transition-all font-medium flex items-center gap-1.5"
                    type="button"
                    :disabled="loading"
                    @click="search"
                >
                    <font-awesome-icon :icon="['far', 'magnifying-glass']" />
                    Search
                </button>
            </div>
        </div>
        <!--End of filters section -->

        <!-- Start of search database -->
        <div
            class="p-4 [&_.slider-input]:w-full filter [&_.slider-input]:px-3 [&_.input-field.relative]:items-center [&_.input-field.relative]:flex-row-reverse [&_.input-field.relative]:justify-end [&_.input-field.relative]:gap-x-4 [&_.input-field.relative]:flex [&_.input-field.relative_label]:mb-0"
        >
            <!-- Start of Basic search form-->
            <FormsBasicForm :key="filterRender || defaults" :schema="basicSearchForm" :default-values="defaults" @blur="update" @input="update" @reset="reset" />
            <!-- End of Basic search form -->
        </div>
        <div class="intrested-block bg-yellow-50 border border-yellow-300 flex gap-x-4 items-center justify-between px-5 py-3.5 mt-4 fixed bottom-0" @click="navigateTo('/services')">
            <div class="flex gap-3 items-center">
                <span class="text-[20px]"><font-awesome-icon :icon="['fas', 'crown']" style="color: rgb(254, 172, 44)" /></span>
                <div><p class="leading-6 text-xs">Interested in fully managed VIP services?</p></div>
            </div>
        </div>
        <!-- Candidate cards section -->
        <div v-if="display === 'tabs'" :key="render">
            <CandidateCards :response="userSearchInput" :is-loading="loading" @scroll="loadMoreRecords" />
        </div>

        <!-- Show LogoLoading component when loading -->
        <LogoLoading v-if="loading" />
    </div>
</template>
<script setup lang="ts">
import { ref, defineProps } from 'vue'
import { useAuthLazyFetchPost, useHandlebars, onMounted } from '#imports'
import basicSearchForm from '~~/data/candidate-search.json'

interface Props {
    prefillSkill: object[]
}
const props = defineProps<Props>()
const defaults: any = ref({})
const searchData: any = ref([])
const display = ref('input')
const userSearchInput = ref()
const render = ref(false)
const limit = ref(10)
const offset = ref(0)
const candidateSearchResults = ref([])
const loading = ref(false)
const filterRender = ref(0)
const emits = defineEmits(['search-data'])

onMounted(() => {
    defaults.value = {
        current_designation: props.prefillSkill?.role ? [props.prefillSkill?.role] : '',
        skills: props.prefillSkill?.skills,
        currently_working: props.prefillSkill?.currently_working ? [props.prefillSkill?.currently_working] : '',
        actively_searching: props.prefillSkill?.actively_searching ? props.prefillSkill?.actively_searching : false,
        departments: props.prefillSkill?.departments ? [props.prefillSkill?.departments] : '',
        education: props.prefillSkill?.education,
        languages_known: props.prefillSkill?.languages_known,
        gender: props.prefillSkill?.gender,
        job_type: props.prefillSkill?.job_type,
        experience: props.prefillSkill?.search_details?.experience ? props.prefillSkill?.search_details?.experience : [0, 0],
        salary: props.prefillSkill?.search_details?.salary ? props.prefillSkill?.search_details?.salary : [0, 0],
    }
    filterRender.value++
})

// Function to update search data
const update = (searchItem: any) => {
    searchData.value = searchItem
}

// Function to perform search
const search = async () => {
    loading.value = true // Set loading to true before the search starts
    const gender = searchData?.value?.gender
    const body = {
        skill: searchData.value?.skills || '',
        job_location: searchData.value?.city || [],
        current_designation: searchData.value?.role ? [searchData.value?.role] : [],
        currently_working: searchData.value?.currently_working || '',
        notice_period: searchData.value?.notice_period || 'Immediately',
        total_experience: {
            min: searchData?.value?.search_details?.experience[0],
            max: searchData?.value?.search_details?.experience[1],
        },
        department: searchData.value?.departments || '',
        language: searchData?.value?.languages_known?.[0] || '',
        institute: searchData?.value?.institutions?.[0] || '',
        degree: searchData?.value?.education?.[0] || '',
        job_type: searchData?.value?.job_type || '',
        salary: {
            min: searchData?.value?.search_details?.salary[0],
            max: searchData?.value?.search_details?.salary[1],
        },
        ...(gender && { gender }),
    }
    emits('search-data', body)
    const { data: response } = await useAuthLazyFetchPost(useHandlebars('{{ candidateSearchURL }}?query_type=search&limit={{limit}}&offset={{offset}}', { limit: limit.value, offset: offset.value }), {
        body,
    })
    if (response.value) {
        candidateSearchResults.value.push(...response.value)
        loading.value = true // Set loading to true
        userSearchInput.value = response.value
        render.value += 1
    }
    loading.value = false // Set loading to false after the search completes
}
// Load more records while scrolling when it reach to bottom
const loadMoreRecords = (data: any) => {
    if (data) {
        offset.value += limit.value // Increment offset based on limit
        search() // Trigger search function
    }
}

// Reset the input fields form
const clear = () => {
    reset()
}

// Reset the input fields form
const reset = () => {
    defaults.value = {}
    filterRender.value++
}
</script>
<style>
.filter [type='checkbox'] {
    width: 20px;
    height: 20px;
}
.card-container {
    max-height: 100vh; /* Set a maximum height for the container */
    overflow-y: auto; /* Enable vertical scrolling */
    /* Add any additional styles for the container */
}
.candidates-filter {
    max-height: 90vh;
    overflow-y: auto;
}
.filter .slider-input .w-56.mx-auto {
    width: 100%;
}
.filter .slider-input .w-56.mx-auto .relative.inline-block.text-left {
    width: 100%;
}
.filter .slider-input button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75 {
    width: 100%;
    font-size: 0.875rem !important;
    line-height: 0;
    padding-left: 10px;
}
.filter .slider-input button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75 .flex.justify-between span {
    border: none;
    width: auto;
    padding-left: 0;
    font-size: 14px;
    color: #334151;
    font-weight: 400;
}
.filter
    .slider-input
    button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75
    .flex.justify-between
    span:nth-child(2)
    svg {
    display: none;
}
.filter
    .slider-input
    button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75
    .flex.justify-between
    span:nth-child(2)::after {
    content: '';
    position: absolute;
    right: 15px;
    top: 18px;
    width: 0;
    height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid #999;
}
.filter .slider-input button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75 .flex.justify-between {
    width: 100%;
}
.filter .slider-input {
    padding-left: 0;
    padding-right: 0;
    border: 1px solid #d1d5db;
    border-radius: 5px;
    height: 45px;
}
.filter .slider-input .flex.flex-col.text-\[14px\].max-w-\[200px\] {
    width: 120px;
}

.filter .slider-input .relative.z-10.px-4.pb-4.pt-4.bg-white.transition-effect.rounded-md.border-t.border-skin-base\/40 {
    border: none;
    box-shadow: 0px 0px 5px #cecbcb;
}
</style>
