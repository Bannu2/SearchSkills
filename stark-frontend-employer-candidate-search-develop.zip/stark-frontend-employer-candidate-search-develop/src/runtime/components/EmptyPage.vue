<!-- eslint-disable vue/no-multiple-template-root -->
<template>
    <div>
        <div class="border border-skin-base/10 p-5 bg-skin-white rounded-md md:h-[86vh] overflow-auto">
            <h2 class="text-xl text-skin-base mb-2 font-semibold text-center">Candidates Search Result</h2>
            <div class="text-center mt-64">
                <font-awesome-icon :icon="['fas', 'user-magnifying-glass']" class="text-skin-base text-7xl mb-4" />
                <h1 class="text-skin-base text-xl font-semibold mb-2">No Candidate Found</h1>
                <h4 class="text-sm text-skin-base">Consider adjusting your search criteria to find suitable candidates for your job application.</h4>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts"></script>
