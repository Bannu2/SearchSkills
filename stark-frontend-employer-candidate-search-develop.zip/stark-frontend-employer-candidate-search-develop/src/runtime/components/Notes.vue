<template>
    <div
        class="talent-source-notes [&_.bg-skin-white.border-b.border-skin-base\/5.flex.px-5.py-4.sticky.top-0.items-center]:hidden [&_.md\:flex.items-center.justify-between.pb-5.w-full.table-header]:hidden [&_.user-name]:!text-neutral-900 [&_.user-name]:-mt-4 [&_.user-name]:font-medium [&_.ml-\[2\.5rem\].flex-1]:-mt-4 [&_.ml-\[2\.5rem\].flex-1_p]:text-xs [&_.ml-\[2\.5rem\].flex-1_p_div]:truncate [&_.ml-\[2\.5rem\].flex-1_p_div]:max-w-[130px] [&_.fa-solid.fa-paper-plane-top.text-skin-white.text-\[13px\].p-\[5px\]]:-ml-2 [&_.divide-skin-secondary\/10.cursor-pointer.group.col-span-1]:m-[10px_10px_0_10px] [&_.divide-skin-secondary\/10.cursor-pointer.group.col-span-1]:rounded-[4px] [&_.divide-skin-secondary\/10.cursor-pointer.group.col-span-1]:border [&_.divide-skin-secondary\/10.cursor-pointer.group.col-span-1]:border-[#f5f5f5]"
    >
        <NotesMain :entity-id="props.notes" entity="CANDIDATES" :notes-u-r-l="notesData" />
    </div>
</template>
<script setup lang="ts">
import { useHandlebars } from '#imports'
interface Props {
    notes: String
}
const props = withDefaults(defineProps<Props>(), {})
const notesData = useHandlebars('{{ notesURL }}')
</script>
