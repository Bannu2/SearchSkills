<!-- eslint-disable @typescript-eslint/no-unused-vars -->
<!-- eslint-disable vue/no-v-html -->
<!-- eslint-disable vue/require-v-for-key -->
<template>
    <div>
        <div v-for="(card, index) in cards">
            <div :key="index" class="px-2 lg:px-0">
                <h3 class="font-medium text-sm text-skin-base mb-2.5 flex items-center"><span class="mr-2 text-base"></span> Assesment History</h3>

                <div class="border job-feature-card rounded-md bg-skin-white p-6 mb-3">
                    <div class="mb-2">
                        <h2 v-if="card?.answers?.name" class="text-skin-base text-sm truncate max-w-[350px] font-medium mb-2">
                            <font-awesome-icon :icon="['far', 'graduation-cap']" /> Completed Advance {{ card?.answers?.name }} Assesment
                        </h2>
                        <div class="flex justify-between items-center">
                            <h2 v-if="card?.score" class="font-medium text-skin-base/60 text-xs uppercase">Scored {{ card?.score }}%</h2>
                            <h2 v-if="card?.end_time" class="font-medium text-skin-base/60 text-xs uppercase">
                                {{ useTimeAgo(card?.end_time) }}
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useTimeAgo } from '@vueuse/core'
import { useAuthLazyFetch, useHandlebars } from '#imports'
const cards = ref()
interface Props {
    assessment: String
}
const props = withDefaults(defineProps<Props>(), {})
onMounted(() => {
    setTimeout(() => {
        getCardsData()
    }, 100)
})

const getCardsData = async () => {
    // Assign response to Cards variable which is ahbdliing in loop

    const { data: response } = await useAuthLazyFetch(
        useHandlebars(
            `{{ assesmentHistoryURL }}?visibility_status=company&sort_column=id&sort_direction=desc&offset=0&limit=100&filters=%5B%7B%22stark_candidate_profile_id%22%3A%20%22${props.assessment}%22%7D%5D`,
        ),

        {},
    )

    cards.value = response.value
}
</script>
