<template>
    <div>
        <div class="flex items-center w-fit rounded-md">
            <!-- Start of bookmark button -->
            <font-awesome-icon
                :icon="['far', 'fa-bookmark']"
                class="text-skin-white hover:text-skin-base transition-all duration-300 px-3 py-2.5 hover:bg-skin-primary text-[14px] border border-[#fafafa30] cursor-pointer"
                @click="postCandidate()"
            />
            <!-- End of bookmark button -->

            <!-- Start of sendMail button -->
            <font-awesome-icon
                :icon="['far', 'fa-envelope']"
                class="text-skin-white hover:text-skin-base transition-all duration-300 px-3 py-2.5 hover:bg-skin-primary text-[14px] border border-[#fafafa30] cursor-pointer"
                @click.prevent.stop="openSendEmail"
            />
            <!-- End of sendMail button -->

            <!-- Start of WhatsApp button -->
            <i
                class="fa-brands fa-whatsapp text-skin-white hover:text-skin-base transition-all duration-300 px-3 py-2.5 hover:bg-skin-primary text-[14px] border border-[#fafafa30] cursor-pointer"
                @click.prevent="whatsappWeb"
            ></i>
            <!-- End of WhatsApp button -->

            <!-- Component to load Twilio or SIP dialer for composables  -->
            <TwilioShowDial class="twilio-showdial" />

            <!-- Start of calendar button -->
            <font-awesome-icon
                :icon="['far', 'phone']"
                class="text-skin-white hover:text-skin-base transition-all duration-300 px-3 py-2.5 hover:bg-skin-primary text-[14px] border border-[#fafafa30] cursor-pointer rounded-r-md"
                @click.prevent="showDial"
            />
            <!-- End of calendar button -->
        </div>
    </div>
</template>
<script setup lang="ts">
import { ref, onMounted } from 'vue'
import { useAppConfig } from 'nuxt/app'
import { useShowEmail, useDomainStore, useAuthLazyFetch, getPhoneNumbers, useShowDial, useAuthLazyFetchPost, useHandlebars, useShowNoty, useShowSIPDial } from '#imports'
interface Props {
    button: String
}
const props = withDefaults(defineProps<Props>(), {})
const appConfig = useAppConfig()

/**
 * Navigate to whatsapp web in a new tab
 */
const whatsappWeb = () => {
    /**
     * Fetch phone number from button
     */
    let phoneNumber = props.button?.phone.replaceAll(' ', '')
    phoneNumber = phoneNumber.replaceAll('+', '')

    if (phoneNumber) {
        /**
         * If phoneNumber exist open whatsapp with phone number
         */
        window.open(`https://api.whatsapp.com/send/?phone=${phoneNumber}&text&type=phone_number&app_absent=0`, '_blank')
    } else {
        /**
         * Else open whatsapp home
         */
        window.open('https://web.whatsapp.com/', '_blank')
    }
}
const prompts = ref([
    {
        name: 'Initial Outreach',
        icon: 'fa-duotone fa-envelope hover:text-skin-primary text-skin-muted',
        prompt: 'Generate an initial outreach email subject and body. Subject: "Exciting Job Opportunity Awaits You!" Body: Briefly introduce the sender, express interest in the candidates profile, mention a job opportunity aligned with their skills, and invite them to discuss further. End with the [Recruiters name] and contact information.',
    },
    {
        name: 'Interview Invitation',
        icon: 'fa-duotone fa-calendar-users hover:text-skin-primary text-skin-muted ',
        prompt: 'Generate an interview invitation email subject and body. Subject: "Interview Invitation for [Job Title] Position." Body: Warmly invite the candidate for an interview, express admiration for their qualifications, include date, time, and location details. Encourage confirmation and end with anticipation for the meeting with [Managers name],[Managers Title], along with the [Recruiters name] and contact information.',
    },
    {
        name: 'Interview Reminder',
        icon: 'fa-duotone fa-calendar-users hover:text-skin-primary text-skin-muted ',
        prompt: 'Generate an interview reminder email subject and body. Subject: "Reminder: Interview for [Job Title] Tomorrow." Body: Remind the candidate of the scheduled interview, include date, time, and location details. Encourage preparation, invite questions, and express enthusiasm for the meeting. End with the  [Recruiters name] and contact information.',
    },
    {
        name: 'Application Reminder',
        icon: 'fa-duotone fa-calendar-users hover:text-skin-primary text-skin-muted ',
        prompt: 'Generate an application deadline reminder email subject and body. Subject: "Reminder: [Job Title] Application Deadline Approaching." Body: Express appreciation for the candidates interest, remind them of the application deadline for a specific job title, encourage timely submission, and include any relevant details. End with appreciation and the s[Recruiters name] and contact information',
    },
])
const aiPrompt = ref({
    enabled: true,
    prompt: 'Write a mail to manager to change position',
    title: 'Generate Content',
    placeholder: 'Enter prompt',
    prompts: prompts.value,
    saveButtonLabel: 'Insert into mail',
    maxToken: 4000,
})
const templateURL = '{{emailTemplatesURL}}?offset=0&limit=100&sort_column=id&sort_direction=desc'
/**
 * Open send email modal
 */
const openSendEmail = () => {
    useShowEmail(
        'Send Email',
        '',
        '',
        '',
        templateURL,
        props?.button,
        aiPrompt.value,
        '',
        '',
        [props?.button.email],
        [],
        '',
        '',
        {},
        `${appConfig.candidateSearchURL}?sort_column=id&sort_direction=desc`,
    )
}
const plugin = ref({})

onMounted(() => {
    setTimeout(async () => {
        useDomainStore().getDomainFromServer()
        // Get plugin details
        const { data: response } = await useAuthLazyFetch(useHandlebars('{{userPluginsURL}}?q=provider_name={{appName}}&offset=0&limit=100&sort_column=id&sort_direction=desc'), {})

        // Check plugin availabile or not
        response?.value?.forEach((item: any) => {
            if (item.plugin_name === 'Twilio' || item.plugin_name === 'SIP') plugin.value = item
        })

        // Get twilio phone numbers
        if (plugin.value?.plugin_name === 'Twilio') numbers.value = await getPhoneNumbers(plugin.value.uid)
    }, 0)
})

const numbers = ref([])

// Show dialer
const showDial = () => {
    let phoneNumber = props.button?.phone.replaceAll(' ', '')
    phoneNumber = phoneNumber.replaceAll('+', '')

    // Show dialer based on configured plugin
    if (plugin.value && plugin.value.plugin_name === 'SIP') useShowSIPDial(plugin.value, true, phoneNumber, props?.button?.first_name, '', 'text-sm')
    else useShowDial(plugin.value.uid, numbers.value, true, phoneNumber, props?.button?.first_name, '', 'text-sm')
}

const postCandidate = async () => {
    const { data: response } = await useAuthLazyFetchPost(useHandlebars('{{candidatesURL}}'), {
        body: {
            first_name: props.button.first_name,
            last_name: props.button.last_name,
            email: props.button.email,
            phone_number: props.button.phone,
            skills: [
                {
                    name: props.button.skills[0].name,
                },
            ],
            education: props.button.education,
            experience: props.button.experience,
            social_profiles: props.button.social_profiles,
            designation: props.button.current_designation,
            resume_url: props.button.resume_url ? props.button.resume_url : 'string',
            gender: props.button.info.gender.toUpperCase(),
            date_of_birth: props.button.info.dob,
            work_experience: 0,
            source: 'Stark',
            currency_code: 'INR',
            current_salary: 0,
            expected_salary: 0,
            stage: 'string',
            pic_url: '',
            cdata1: {},
            locations: props.button.auto_apply_prefs.job_location ? props.button.auto_apply_prefs.job_location : [],
            tags: [],
            is_bookmarked: false,
        },
    })

    if (response.value) useShowNoty('success', 'Candidate Added successfully')
}
</script>
