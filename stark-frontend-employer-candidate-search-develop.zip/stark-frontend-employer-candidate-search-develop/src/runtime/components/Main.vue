<template>
    <!-- Start of jobs search -->
    <div class="bg-skin-rhs h-screen overflow-auto">
        <div class="employer-search-main">
            <!-- Start of jobs search -->
            <CandidateSearch />
        </div>
    </div>
    <!-- End of jobs search -->
</template>

<style>
.active {
    background-color: lightblue;
    /* Change this to the desired color */
}
.ql-editor.ql-blank {
    font-family: 'Inter var', sanserif !important;
}
.collapse-enter-to,
.collapse-enter-active,
.collapse-leave-active {
    max-height: 0;
    overflow: hidden !important;
}

.collapse-enter-active,
.collapse-enter-to,
.collapse-active,
.collapse-leave-active,
.collapse-leave-to {
    overflow: hidden !important;
}

.bar .caption {
    box-shadow: none !important;
}

.bar .bar-right,
.bar .bar-left {
    box-shadow: none !important;
    --tw-bg-opacity: 1;
    background-color: rgba(var(--color-base), 0.1) !important;
}

.bar .bar-inner {
    border: 0px !important;
}

.multi-range-slider-bar-only .thumb::before {
    border: 0px !important;
    box-shadow: none !important;
    background-color: rgba(var(--color-base), 1) !important;
    content: '';
    position: absolute;
    width: 20px;
    height: 20px;
    border: solid 1px rgba(var(--color-base), 1) !important;
    box-shadow:
        0px 0px 3px rgba(var(--color-base), 1),
        inset 0px 0px 5px rgba(var(--color-base), 1);
    border-radius: 50%;
    z-index: 1;
    left: 1px;
    cursor: pointer;
    top: 1px;
}

.bar .bar-inner {
    border-color: rgba(var(--color-base), 0.5) !important;
}

.bar .max-caption,
.bar .min-caption {
    padding: 0px 10px !important;
    font-weight: 600 !important;
    box-shadow: none !important;
    --tw-bg-opacity: 1;
    top: -9px;
    background-color: rgba(var(--color-base), 1) !important;
}

.multi-range-slider-bar-only .bar-inner {
    box-shadow: none !important;
    --tw-bg-opacity: 1;
    top: 0;
    background-color: rgba(var(--color-base), 0.5) !important;
}

.col-span-6 .slider-input {
    position: relative;
}

.col-span-6 .slider-input label {
    display: block;
    position: absolute;
    left: 20px;
    top: 3px;
}

.col-span-6 .slider-input {
    padding-left: 120px;
}

.mt-1.text-xs.leading-6.text-skin-muted {
    margin-top: 0px !important;
    line-height: 1;
}

.switch-toggle {
    margin-top: 8px !important;
}

.multi-range-slider-bar-only .bar-inner-left,
.multi-range-slider-bar-only .bar-inner-right,
.multi-range-slider-bar-only .bar-inner {
    background-color: rgba(var(--color-primary), 0.1) !important;
}

.grid.grid-cols-1.gap-x-6.gap-y-4 > :not([hidden]) ~ :not([hidden]) {
    border-color: rgba(var(--color-base), 0.1) !important;
}

.multiselect::after {
    right: 21px !important;
}
.multi-range-slider-bar-only .bar-inner {
    --tw-bg-opacity: 1;
    background-color: #facc15 !important;
    box-shadow: none !important;
    top: 0;
}
.multi-range-slider-bar-only .thumb:before {
    background-color: #fff;
    border: 1px solid #000;
    border-radius: 50%;
    box-shadow:
        0 0 3px #000,
        inset 0 0 5px gray;
    content: '';
    cursor: pointer;
    height: 20px;
    margin: -8px;
    position: absolute;
    width: 20px;
    z-index: 1;
}
.multi-range-slider-bar-only .thumb:before {
    background-color: #fff !important;
    border: 2px solid #fff !important;
    box-shadow: 0 0 2px 2px #d9d9d9 !important;
}
.multi-range-slider-bar-only .bar-inner,
.multi-range-slider-bar-only .bar-inner-left,
.multi-range-slider-bar-only .bar-inner-right {
    height: 4px;
}
.advance-search .w-56.mx-auto {
    width: 100%;
}
.advance-search .w-56.mx-auto .relative.inline-block.text-left {
    width: 100%;
}
.advance-search button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75 {
    width: 100%;
    border: none !important;
    font-size: 0.875rem !important;
    line-height: 0;
    padding-right: 0;
    padding-top: 0;
    padding-bottom: 0;
}
.advance-search button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75 .flex.justify-between span {
    border: none;
    width: 100%;
    padding-left: 0;
    font-size: 14px;
    color: #334151;
    font-weight: 400;
}
.advance-search
    button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75
    .flex.justify-between
    span:nth-child(2)
    svg {
    display: none;
}
.advance-search
    button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75
    .flex.justify-between
    span:nth-child(2)::after {
    content: '';
    position: absolute;
    right: 3px;
    top: 10px;
    width: 0;
    height: 0;
    border-left: 4px solid transparent;
    border-right: 4px solid transparent;
    border-top: 4px solid #1c45ab;
}
.advance-search button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75 .flex.justify-between {
    width: 100%;
}
.advance-search .slider-input .flex.flex-col.text-\[14px\].max-w-\[200px\] {
    width: 150px;
}
.advance-search .slider-input .relative.z-10.px-4.pb-4.pt-4.bg-white.transition-effect.rounded-md.border-t.border-skin-base\/40 {
    border: none;
    box-shadow: 0px 0px 5px #cecbcb;
}
.advance-search .w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base {
    text-align: left;
}
.filter .slider-input .w-56.mx-auto .relative.inline-block.text-left {
    width: 100%;
    line-height: 44px;
}
.filter .slider-input button.w-\[450px\].box-border.rounded-md.bg-skin-white.px-5.py-3.text-sm.font-medium.text-skin-base.focus\:outline-none.focus-visible\:ring-white\/75 .flex.justify-between span {
    color: #a1a3a5;
}
</style>
