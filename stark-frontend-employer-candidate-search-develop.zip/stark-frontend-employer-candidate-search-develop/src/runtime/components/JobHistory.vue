<template>
    <div v-if="cards && cards.length">
        <h3 class="font-medium text-sm text-skin-base mb-2.5 flex items-center">Job Applied History</h3>
        <div class="border job-feature-card rounded-xl bg-skin-white p-6 mb-3">
            <div v-for="(card, index) in cards" :key="index" class="mb-4 last:mb-0">
                <div class="space-y-0.5">
                    <div class="flex text-xs gap-x-2 items-start">
                        <div>
                            <font-awesome-icon
                                class="h-12 text-skin-base"
                                icon="fa-solid fa-suitcase fa-2xl"
                                style="--fa-primary-color: #d5ac15; --fa-primary-opacity: 6; --fa-secondary-color: #fde750; --fa-secondary-opacity: 60"
                            />
                        </div>
                        <div>
                            <CandidateJobDetails :details="card?.job_id" />
                            <h2 v-if="card?.created_date" class="font-medium text-skin-base/60 text-xs uppercase">
                                {{ useTimeAgo(card?.created_date) }}
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div v-else>
        <!-- Show something else or leave it empty if there are no badges -->
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useTimeAgo } from '@vueuse/core'
import { useAuthLazyFetch, useHandlebars } from '#imports'
const cards = ref()
interface Props {
    data: String
}
const props = withDefaults(defineProps<Props>(), {})
onMounted(() => {
    setTimeout(() => {
        getJobHistory()
    }, 100)
})

const getJobHistory = async () => {
    const { data: response } = await useAuthLazyFetch(
        useHandlebars(`{{ jobApplicantsURL }}?visibility_status=company&sort_column=id&sort_direction=desc&offset=0&limit=100&filters=%5B%7B%22profile_id%22%3A%20%22${props.data}%22%7D%5D`),

        {},
    )

    cards.value = response.value
}
</script>
