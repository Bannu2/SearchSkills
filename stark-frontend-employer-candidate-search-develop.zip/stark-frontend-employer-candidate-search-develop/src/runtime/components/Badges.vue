<!-- eslint-disable @typescript-eslint/no-unused-vars -->
<!-- eslint-disable vue/no-v-html -->
<!-- eslint-disable vue/require-v-for-key -->

<template>
    <div v-if="cards && cards.length">
        <h3 class="font-medium text-sm text-skin-base mb-2.5 flex items-center">
            <span class="mr-2 text-base">
                <font-awesome-icon :icon="['fal', 'award']" />
            </span>
            Stark Badges Earned
        </h3>
        <div class="border border-skin-base/10 job-feature-card rounded-md bg-skin-white p-4 mb-3 space-y-3 max-h-[300px] overflow-auto scrollbar-thin scrollbar-thumb-[#6666664f]">
            <div v-for="(card, index) in cards" :key="index" class="">
                <div class="space-y-0.5">
                    <div class="flex gap-x-2 items-start">
                        <div>
                            <font-awesome-icon
                                class="h-12"
                                icon="fa-duotone fa-trophy-star fa-2xl"
                                style="--fa-primary-color: #d5ac15; --fa-primary-opacity: 6; --fa-secondary-color: #fde750; --fa-secondary-opacity: 60"
                            />
                        </div>
                        <div>
                            <h2 v-if="card?.skill" class="text-skin-base text-[13px] font-medium">Completed {{ card?.skill }} {{ card?.level }} Certified</h2>
                            <h2 v-show="card?.score !== undefined || card?.score === 0" class="font-medium text-skin-base/60 text-[13px] uppercase">{{ card?.score ?? 0 }}%</h2>

                            <h2 v-if="card?.created_date" class="font-medium text-skin-base/60 text-[13px] uppercase">
                                {{ useTimeAgo(card?.created_date) }}
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div v-else>
        <!-- Show something else or leave it empty if there are no badges -->
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useTimeAgo } from '@vueuse/core'
import { useAuthLazyFetch, useHandlebars } from '#imports'
const cards = ref()
interface Props {
    badges: String
}
const props = withDefaults(defineProps<Props>(), {})
onMounted(() => {
    setTimeout(() => {
        getCardsData()
    }, 100)
})

const getCardsData = async () => {
    // Assign response to Cards variable which is ahbdliing in loop

    const { data: response } = await useAuthLazyFetch(
        useHandlebars(`{{ badgesURL }}/?domain=${props.badges}&offset=0&limit=100&sort_column=id&sort_direction=desc`),

        {},
    )

    cards.value = response.value
}
</script>
