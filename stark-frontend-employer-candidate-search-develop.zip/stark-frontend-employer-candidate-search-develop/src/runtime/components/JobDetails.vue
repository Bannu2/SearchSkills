<template>
    <div v-if="cards && cards.length">
        <div v-for="(card, index) in cards" :key="index" class="mb-6">
            <div class="space-y-0.5">
                <div class="flex gap-x-2 items-start">
                    <div>
                        <h2 v-if="card?.title" class="text-skin-base text-[13px] font-medium">{{ card?.title }} , {{ card.locations.join(', ') }}</h2>
                    </div>
                </div>
            </div>
        </div>
        <!-- </div> -->
    </div>
    <div v-else>
        <!-- Show something else or leave it empty if there are no badges -->
    </div>
</template>

<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useAuthLazyFetch, useHandlebars } from '#imports'
const cards = ref()
interface Props {
    details: String
}
const props = withDefaults(defineProps<Props>(), {})
onMounted(() => {
    setTimeout(() => {
        getJobDetails()
    }, 100)
})

const getJobDetails = async () => {
    const { data: response } = await useAuthLazyFetch(
        useHandlebars(`{{jobsURL}}?visibility_status=company&sort_column=id&sort_direction=desc&offset=0&limit=100&filters=%5B%7B%22uid%22%3A%22${props.details}%22%7D%5D`),

        {},
    )

    cards.value = response.value
}
</script>
