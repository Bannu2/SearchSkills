<!-- eslint-disable vue/no-template-shadow -->
<!-- eslint-disable vue/require-v-for-key -->
<!-- eslint-disable vue/no-v-html -->
<template>
    <!-- Container for the card layout -->
    <div v-if="cards && cards.length > 0" ref="cardContainer" class="card-container scrollbar-thin scrollbar-thumb-[#6666664f] candidates-results mt-4" @scroll="handleScroll">
        <!-- Loop through cards -->
        <div
            v-for="(card, index) in cards"
            :key="index"
            class="border bg-skin-white cursor-pointer rounded-md mb-4 [&_.download-resume]:hover:visible shadow-sm hover:shadow-lg transition-all duration-300"
        >
            <!-- Start of candidate card content -->
            <div class="flex flex-col justify-between relative">
                <div class="flex flex-col gap-4 p-4" @click="toggleCardDescription(index)">
                    <div class="flex gap-4">
                        <!-- Image section -->
                        <!-- Display user image -->
                        <nuxt-img
                            v-if="card?._source?.pic_url"
                            loading="lazy"
                            width="100%"
                            height="100%"
                            alt="user"
                            :src="isJsonString(card?._source?.pic_url) ? JSON.parse(card?._source?.pic_url).file_url : card?._source?.pic_url"
                            class="object-cover shrink-0 w-[75px] rounded-lg h-[75px] border border-skin-base/10 overflow-hidden"
                        />

                        <!--Candidate details section -->
                        <div class="w-full flex flex-col candidate-info-details">
                            <div class="job-match flex items-center">
                                <!-- Display job title -->
                                <p class="text-sm text-yellow-500 first-letter:capitalize">
                                    {{
                                        Array.isArray(card._source.auto_apply_prefs && card._source.auto_apply_prefs.job_title)
                                            ? card._source.auto_apply_prefs.job_title.join(', ')
                                            : card._source.auto_apply_prefs
                                            ? card._source.auto_apply_prefs.job_title
                                            : ''
                                    }}
                                </p>
                            </div>
                            <!-- Display user name -->
                            <div class="job-match flex items-center">
                                <h2 v-if="card?._source?.first_name" class="text-[14px] font-medium text-neutral-900 mb-1 capitalize cursor-pointer mr-2">
                                    {{ card?._source?.first_name }} {{ card?._source?.last_name ? card?._source?.last_name : '' }}
                                </h2>
                                <div v-if="card?._source?.matched_percentage" class="flex items-end gap-2.5">
                                    <span class="inset-1 pl-0.5 text-neutral-900 flex flex-col justify-center items-center text-xs font-semibold"
                                        >{{ card?._source?.matched_percentage.toFixed(0) }}% Match</span
                                    >
                                </div>
                            </div>
                            <!-- Display user location -->
                            <div class="flex items-center flex-wrap text-[13px] text-gray-500 gap-4 mt-1">
                                <div class="flex items-end gap-x-2">
                                    <div v-if="card._source.auto_apply_prefs && card._source.auto_apply_prefs.currently_working" class="flex items-end gap-x-2">
                                        <span>
                                            <font-awesome-icon :icon="['fal', 'map-location-dot']" class="fill-current text-base" />
                                        </span>
                                        <span class="first-letter:capitalize">
                                            {{
                                                Array.isArray(card._source.auto_apply_prefs.currently_working)
                                                    ? card._source.auto_apply_prefs.currently_working[0]
                                                    : card._source.auto_apply_prefs.currently_working || ''
                                            }}
                                        </span>
                                    </div>
                                    <span v-else class="first-letter:capitalize"> Not Specified</span>
                                </div>
                                <!-- Display user experience -->
                                <div v-if="card?._source?.auto_apply_prefs?.total_experience" class="flex items-end gap-x-2">
                                    <span>
                                        <font-awesome-icon :icon="['fal', 'fa-business-time']" class="fill-current text-base" />
                                    </span>
                                    <span class="first-letter:capitalize">{{ card?._source?.auto_apply_prefs?.total_experience }}Years </span>
                                </div>
                                <!-- Display user salary -->
                                <div v-if="card?._source?.auto_apply_prefs?.current_salary" class="flex items-center gap-x-2">
                                    <font-awesome-icon :icon="['fal', 'fa-money-bills']" />
                                    <span class="first-letter:capitalize">{{ card?._source?.auto_apply_prefs?.current_salary }} INR </span>
                                </div>

                                <!-- Display user availability -->
                                <div v-if="card?._source?.auto_apply_prefs?.available" class="flex items-end gap-x-2">
                                    <span>
                                        <font-awesome-icon :icon="['fal', 'fa-briefcase']" class="fill-current text-base" />
                                    </span>
                                    <span>{{ card?._source?.auto_apply_prefs?.available }}</span>
                                </div>
                                <!--Start of notice period-->
                                <div v-if="card?._source?.auto_apply_prefs?.join" class="flex items-center gap-x-2">
                                    <font-awesome-icon :icon="['fal', 'fa-calendar-days']" />
                                    <span class="first-letter:capitalize">{{ card?._source?.auto_apply_prefs?.join }} days </span>
                                </div>
                                <!--End of notice period-->
                            </div>
                        </div>
                    </div>
                    <!--Start of job summary-->
                    <div class="job-summary flex">
                        <font-awesome-icon :icon="['fal', 'square-list']" class="text-neutral-900 text-[18px] mr-[10px] mt-[2px]" />
                        <p v-if="card?._source?.summary" class="text-gray-500 text-[14px] line-clamp-2 first-letter:capitalize" v-html="card?._source?.summary"></p>
                    </div>
                    <!--Start of job skills-->
                    <ul class="flex items-center flex-wrap gap-1.5 text-[13px] candidate-skills-list">
                        <div v-for="skill in card?._source?.skills" class="capitalize bg-[#fafafa] borer-[#f8f8f8] flex gap-x-1 items-center px-2 py-1 rounded-[4px] text-[12px] text-[#475569]">
                            <span class="text-yellow-400"><font-awesome-icon :icon="['far', 'fa-star']" /></span>
                            <span>{{ skill?.name }} </span>
                        </div>
                    </ul>
                    <!--End of job skills-->
                </div>
                <!--End of job summary-->
            </div>
            <!-- End of candidate card content -->
            <!-- Start of modal for expanded card -->
            <Modal
                :open="isCardExpanded(index)"
                type="slideout"
                size="2xl:w-[1600px] xl:w-[1300px] lg:w-[1200px] h-screen [&_.bg-skin-lhs.py-4.px-4]:bg-skin-primary [&_.bg-skin-lhs.py-4.px-4]:hidden [&_.bg-skin-lhs.py-4.px-4]:p-[10px_16px] [&_.bg-skin-lhs.py-4.px-4]:h-[unset] [&_.bg-skin-lhs.py-4.px-4_h3]:text-skin-white [&_.p-6.relative.overflow-auto.bg-skin-white]:p-0 [&_.text-left.p-6.relative.overflow-auto.bg-skin-white]:max-h-[unset] [&_.text-left.p-6.relative.overflow-auto.bg-skin-white]:min-h-[unset] [&_.text-left.p-6.relative.overflow-auto.bg-skin-white]:h-screen [&_.text-left.p-6.relative.overflow-auto.bg-skin-white]:overflow-hidden candidates-slideout theme-midnight"
                :hide="(open = true)"
                :close="false"
                @close="isCardExpanded(index)"
            >
                <!-- Expanded card content -->
                <template #body>
                    <div class="grid grid-cols-12 items-center gap-x-4 border border-skin-base/10 px-4 py-2.5 candidates-slideout-header bg-skin-lhs">
                        <div class="col-span-4">
                            <div class="flex items-center gap-x-3">
                                <div v-if="card?._source?.pic_url" class="w-[60px] shrink-0 h-[60px] rounded-full overflow-hidden">
                                    <!-- Display user image -->
                                    <nuxt-img
                                        loading="lazy"
                                        width="100%"
                                        height="100%"
                                        alt="user"
                                        :src="isJsonString(card?._source?.pic_url) ? JSON.parse(card?._source?.pic_url).file_url : card?._source?.pic_url"
                                        class="h-full w-full object-cover rounded-full"
                                    />
                                </div>
                                <div class="truncate flex flex-col">
                                    <!-- Display user name -->
                                    <h1 class="text-base font-semibold text-skin-white/90 truncate">
                                        {{ card?._source?.first_name ? card?._source?.first_name : '' }} {{ card?._source?.last_name ? card?._source?.last_name : '' }}
                                    </h1>
                                    <p class="text-[13px] text-yellow-500 first-letter:capitalize truncate">
                                        {{
                                            Array.isArray(card?._source?.auto_apply_prefs?.job_title)
                                                ? card._source.auto_apply_prefs.job_title.join(', ')
                                                : card._source.auto_apply_prefs?.job_title || ''
                                        }}
                                    </p>
                                    <!--Start of education section-->
                                    <div v-if="card?._source?.education?.length">
                                        <li v-for="item in card?._source?.education" :key="item" class="relative md:flex md:gap-x-4">
                                            <p class="text-[13px] text-skin-white/80 truncate">{{ item?.degree ? item?.degree : '' }} in {{ item?.field_of_study }}</p>
                                        </li>
                                    </div>
                                    <!--End of education section-->
                                </div>
                            </div>
                        </div>

                        <div class="col-span-8">
                            <div class="flex items-center gap-6 justify-end">
                                <div v-if="card?._source?.matched_percentage" class="flex items-center gap-2.5">
                                    <span class="relative inline-block">
                                        <svg class="w-10 h-10 rotate-[270deg] hidden bg-skin-base/10 rounded-full">
                                            <circle class="text-neutral-900/10" stroke-width="4" stroke="currentColor" fill="transparent" r="17" cx="21" cy="21"></circle>
                                            <circle
                                                class="text-skin-primary"
                                                stroke-width="4"
                                                stroke-dasharray="180"
                                                stroke-dashoffset="(100 - card?._source?.matched_percentage) / 100 * 180"
                                                stroke-linecap="round"
                                                stroke="currentColor"
                                                fill="transparent"
                                                r="17"
                                                cx="21"
                                                cy="21"
                                            ></circle>
                                        </svg>
                                        <span class="inset-1 pl-0.5 text-skin-white flex flex-col justify-center items-center text-xs font-semibold"
                                            >{{ card?._source?.matched_percentage.toFixed(0) }}%</span
                                        > </span
                                    ><span class="text-skin-white text-sm capitalize visible match-score"> Match Score</span>
                                </div>
                                <div class="flex [&_.p-4]:p-0 items-center"><CandidateTags :card-data="card._source" /></div>
                                <div class="relative [&_.absolute.z-20.mt-2.border.microphone-position]:-left-[210px] [&_.absolute.z-20.mt-2.border.microphone-position]:top-10">
                                    <CandidateButtons :button="card?._source" />
                                </div>
                                <div class="cursor-pointer text-skin-white/50 hover:text-skin-white transition-all text-base" @click="toggleCardDescription(index), isCardExpanded(index)">
                                    <font-awesome-icon :icon="['far', 'fa-xmark']" class="text-[24px]" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-12 h-[calc(100vh_-_90px)] bg-skin-rhs candidates-slideout-body">
                        <div
                            class="candidates-slideout-rhs col-span-3 border-r bg-skin-white p-4 flex flex-col gap-4 divide-y divide-skin-base/10 divide-dashed scrollbar-thin overflow-auto scrollbar-thumb-[#6666664f]"
                        >
                            <!-- Start of personal details -->

                            <div class="">
                                <div class="candidate-video-section">
                                    <h4 v-if="card?._source?.uid" class="text-[15px] font-medium text-neutral-900 mb-2 ml-[3px] flex items-center">
                                        <font-awesome-icon :icon="['far', 'video']" class="text-[#3e3e3e] text-[17px] mr-2" />
                                        Video Resume
                                    </h4>
                                    <div class="">
                                        <CandidateVideo :video="card?._source?.uid" class="mb-4" />
                                    </div>
                                </div>
                                <h4 class="text-[15px] font-medium text-neutral-900 mb-2 ml-[3px] flex items-center">
                                    <font-awesome-icon :icon="['far', 'circle-user']" class="text-[#3e3e3e] text-[17px] mr-2" />
                                    Personal Information
                                </h4>
                                <div class="bg-white border border-[#cccccc5e] p-[12px] rounded-md">
                                    <div class="space-y-2.5">
                                        <div v-if="card?._source?.email" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Full Name</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">
                                                {{ card?._source?.first_name ? card?._source?.first_name : '' }} {{ card?._source?.last_name ? card?._source?.last_name : '' }}
                                            </p>
                                        </div>
                                        <div v-if="card?._source?.email" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Email</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">{{ card?._source?.email }}</p>
                                        </div>
                                        <div v-if="card?._source?.phone" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Phone</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">{{ card?._source?.phone }}</p>
                                        </div>
                                        <div v-if="card?._source?.auto_apply_prefs?.current_salary" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Current Salary</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">{{ card?._source?.auto_apply_prefs?.current_salary }}</p>
                                        </div>
                                        <div v-if="card?._source?.auto_apply_prefs?.expected_salary" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Expected Salary</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">{{ card?._source?.auto_apply_prefs?.expected_salary }}</p>
                                        </div>
                                        <div v-if="card?._source?.auto_apply_prefs?.qualification" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Qualifications</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">{{ card?._source?.auto_apply_prefs?.qualification }}</p>
                                        </div>
                                        <div v-if="card?._source?.auto_apply_prefs?.job_title" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Job Title</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">
                                                {{
                                                    Array.isArray(card._source.auto_apply_prefs.job_title)
                                                        ? card._source.auto_apply_prefs.job_title.join(', ')
                                                        : card._source.auto_apply_prefs.job_title || ''
                                                }}
                                            </p>
                                        </div>
                                        <div v-if="card?._source?.hobbies" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Hobbies</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate">{{ card?._source?.hobbies }}</p>
                                        </div>
                                        <div v-if="card?._source?.current_designation" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Current Designation</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate capitalize">{{ card?._source?.current_designation }}</p>
                                        </div>
                                        <div v-if="card?._source?.auto_apply_prefs?.join" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Notice Period</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate capitalize">{{ card?._source?.auto_apply_prefs?.join }}</p>
                                        </div>
                                        <div v-if="card._source.auto_apply_prefs?.currently_working" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Currently working</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate capitalize">
                                                {{
                                                    Array.isArray(card._source.auto_apply_prefs.currently_working)
                                                        ? card._source.auto_apply_prefs.currently_working[0]
                                                        : card._source.auto_apply_prefs.currently_working || ''
                                                }}
                                            </p>
                                        </div>
                                        <span v-if="card?._source?.auto_apply_prefs?.job_location" class="flex justify-between text-[13px] font-medium">
                                            <span class="text-gray-500 text-[12px] w-[40%] font-normal">Ready to relocate</span>
                                            <p class="whitespace-nowrap text-neutral-900 text-[13px] font-normal w-[55%] text-right truncate capitalize">
                                                <template v-for="(job_location, index) in card?._source?.auto_apply_prefs?.job_location.slice(0, 2)">
                                                    <span>{{ job_location }}</span>
                                                    <span v-if="index !== card._source.auto_apply_prefs.job_location.slice(0, 2).length - 1">,</span>
                                                </template>
                                            </p>
                                        </span>
                                        <span v-else class="first-letter:capitalize">Not Specified</span>
                                    </div>
                                </div>
                            </div>
                            <!-- End of personal details -->
                            <div v-if="card?._source?.experience?.length" class="pt-4 work-experience">
                                <h5 class="text-[15px] font-medium text-neutral-900 mb-2 ml-[3px]">
                                    <font-awesome-icon :icon="['far', 'briefcase']" class="text-[#3e3e3e] text-[16px] mr-2" />Work Experiences
                                </h5>
                                <div class="gap-2 flex flex-col border border-[#cccccc5e] p-[12px] pb-[20px] rounded-md">
                                    <ul class="">
                                        <li v-for="(item, index) in card?._source?.experience" :key="item">
                                            <div class="relative pb-4">
                                                <span v-if="card?._source?.experience?.length !== index + 1" class="absolute left-[6px] top-[8px] -ml-px h-full w-[1px] bg-gray-100"></span>
                                                <div class="relative flex space-x-3">
                                                    <div>
                                                        <span class="flex items-center justify-center h-[10px] w-[10px] bg-gray-100 border border-gray-200 rounded-full mt-[10px]"> </span>
                                                    </div>
                                                    <div class="flex min-w-0 flex-1 justify-between space-x-4 pt-1.5">
                                                        <div class="">
                                                            <span class="text-[12.5px] text-gray-500 block mb-[5px]">{{ item?.start_date }} - {{ item?.end_date }}</span>
                                                            <span class="text-[13px] text-neutral-900 block mb-[5px] capitalize">
                                                                <b class="text-[13px] text-gray-500 font-normal">Role : </b>
                                                                {{ item?.title ? item?.title : '' }}
                                                                <template v-if="item?.company"> </template>
                                                            </span>
                                                            <span class="text-[13px] text-neutral-900 block mb-[5px] first-letter:capitalize">
                                                                <b class="text-[13px] text-gray-500 font-normal">Company : </b>
                                                                <template v-if="item?.company"> {{ item?.company }} </template>
                                                            </span>
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize">
                                                                <b class="text-[13px] text-gray-500 font-normal">Department : </b>{{ item?.department }}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!--Start of education section-->
                            <div v-if="card?._source?.education?.length" class="pt-4 education-details">
                                <h5 class="text-[15px] font-medium text-neutral-900 mb-2 ml-[3px]">
                                    <font-awesome-icon :icon="['far', 'building-columns']" class="text-[#3e3e3e] text-[16px] mr-2" />Education
                                </h5>
                                <div class="gap-2 flex flex-col border border-[#cccccc5e] p-[12px] pb-[20px] rounded-md">
                                    <ul class="">
                                        <li v-for="(item, index) in card?._source?.education" :key="item">
                                            <div class="relative pb-4">
                                                <span v-if="card?._source?.education?.length !== index + 1" class="absolute left-[6px] top-[8px] -ml-px h-full w-[1px] bg-gray-100"></span>
                                                <div class="relative flex space-x-3">
                                                    <div>
                                                        <span class="flex items-center justify-center h-[10px] w-[10px] bg-gray-100 border border-gray-200 rounded-full mt-[10px]"> </span>
                                                    </div>
                                                    <div class="flex min-w-0 flex-1 justify-between space-x-4 pt-1.5">
                                                        <div class="">
                                                            <p class="text-[13px] text-gray-500 block mb-[5px]">
                                                                {{ moment(item?.start_date).format('DD/MM/YYYY') }}
                                                                {{ item?.is_pursuing ? 'to Present' : 'to ' + moment(item?.end_date).format('DD/MM/YYYY') }}
                                                            </p>

                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">Degree : </b>{{ item?.degree }}
                                                            </p>
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">School : </b>{{ item?.school }}
                                                            </p>
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">Grade Type : </b>{{ item?.grade }} {{ item?.grade_type }}
                                                            </p>
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">Field of study : </b>{{ item?.field_of_study }}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!--End of education section-->
                            <!--Start of awards section-->
                            <div v-if="card?._source?.awards?.length" class="awards-card bg-skin-white p-4 mb-3 border-2 rounded-md pt-4">
                                <h5 class="text-[15px] font-medium text-neutral-900 mb-2 ml-[3px]">
                                    <font-awesome-icon :icon="['far', 'award']" class="text-[#3e3e3e] text-[17px] mr-2 mt-[2px]" />Certifications and Awards
                                </h5>
                                <div class="gap-2 flex flex-col border border-[#cccccc5e] p-[12px] pb-[20px] rounded-md">
                                    <ul class="">
                                        <li v-for="(item, index) in card?._source?.awards" :key="item">
                                            <div class="relative pb-4">
                                                <span v-if="card?._source?.awards?.length !== index + 1" class="absolute left-[6px] top-[8px] -ml-px h-full w-[1px] bg-gray-100"></span>
                                                <div class="relative flex space-x-3">
                                                    <div>
                                                        <span class="flex items-center justify-center h-[10px] w-[10px] bg-gray-100 border border-gray-200 rounded-full mt-[10px]"> </span>
                                                    </div>
                                                    <div class="flex min-w-0 flex-1 justify-between space-x-4 pt-1.5">
                                                        <div v-for="item in card?._source?.awards" :key="item" class="">
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">Name : </b>{{ item?.name }}
                                                            </p>
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">Associated with : </b>{{ item?.associated_with }}
                                                            </p>
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">Issued by :</b>{{ item?.issued_by }}
                                                            </p>
                                                            <p class="text-[12px] text-neutral-900 line-clamp-3 first-letter:capitalize mb-[5px]">
                                                                <b class="text-[13px] text-gray-500 font-normal">Award date : </b>{{ item?.award_date }}
                                                            </p>
                                                            <p class="text-[12px] text-gray-500 line-clamp-3">{{ item?.description }}</p>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <!--End of awards section-->
                            <div class="pt-4">
                                <CandidateBadges :badges="card?._source?.domain_id" />
                            </div>
                        </div>
                        <div class="col-span-6 p-3 overflow-auto scrollbar-thin scrollbar-thumb-[#6666664f]">
                            <div class="bg-skin-white p-3 rounded-lg mb-2.5">
                                <div>
                                    <h5 class="text-[15px] font-medium text-neutral-900 mb-2 flex items-center">
                                        <font-awesome-icon :icon="['far', 'chart-mixed']" class="text-[#3e3e3e] text-[17px] mr-2" />Stark Analysis
                                    </h5>
                                    <p v-if="card?._source?.summary" class="text-[13px] text-gray-500 line-clamp-3 first-letter:capitalize" v-html="card?._source?.summary"></p>
                                </div>
                                <div class="mt-4">
                                    <h5 class="text-[15px] font-medium text-neutral-900 mb-2 flex items-center">
                                        <font-awesome-icon :icon="['far', 'display-code']" class="text-[#3e3e3e] text-[16px] mr-2" />Skills
                                    </h5>
                                    <ul class="flex items-center flex-wrap gap-1.5 text-[13px]">
                                        <span
                                            v-for="skill in card?._source?.skills"
                                            class="capitalize bg-[#fafafa] borer-[#f8f8f8] flex gap-x-1 items-center px-2 py-1 rounded-[4px] text-[12px] text-[#475569]"
                                        >
                                            <font-awesome-icon :icon="['far', 'fa-star']" class="h-4 text-yellow-400" />
                                            {{ skill?.name }}
                                        </span>
                                    </ul>
                                </div>
                            </div>
                            <div class="p-4 bg-skin-white rounded-lg mb-2.5">
                                <!-- Start of personality traits -->
                                <div class="w-full">
                                    <CandidatePersonalityTraits :candidate-id="card?._source.uid" />
                                </div>
                                <!-- End of  personality traits  -->
                                <!-- Start of employer comments -->
                                <div class="w-full">
                                    <CandidateEmployerComments :candidate-id="card?._source.uid" />
                                </div>
                                <!-- End of employer comments  -->
                            </div>
                            <div class="download-resume visible bg-skin-white p-4 rounded-lg mb-2.5">
                                <h5 class="text-[15px] font-medium text-neutral-900 mb-2 flex items-center">
                                    <font-awesome-icon :icon="['far', 'folder-user']" class="text-[#3e3e3e] text-[17px] mr-2" />Resume
                                </h5>
                                <div v-if="card?._source?.resume_url" class="">
                                    <iframe :src="JSON.parse(card?._source?.resume_url)?.file_url" class="resume-iframe" frameborder="0" style="width: 100%; height: 1200px"></iframe>
                                </div>
                                <div v-else class="bg-skin-white flex flex-col items-center justify-center gap-4 p-6 h-[50vh]">
                                    <img src="https://assets.infinity-api.net/emc2/stark-recruiter/empty-state/no-resume-found.svg" alt="" class="h-[140px]" />
                                    <span class="font-medium text-sm text-neutral-900">No Resume Found</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-span-3 p-3 pl-0 overflow-auto scrollbar-thin scrollbar-thumb-[#6666664f]">
                            <div class="assessment-history">
                                <CandidateAssessmentHistory :assessment="card?._source?.uid" />
                            </div>
                            <div class="mb-2.5 bg-skin-white candidate-notes rounded-md">
                                <div class="items-center justify-between px-3 py-3 text-neutral-900 border-b border-gray-200 flex">
                                    <h3 class="flex font-semibold leading-6 text-neutral-900 text-sm">Notes</h3>
                                </div>
                                <!-- Start of candidate notes -->
                                <div class="">
                                    <CandidateNotes :notes="card?._source?.uid" />
                                </div>
                                <!-- End of candidate notes -->
                            </div>
                            <!-- Start of candidate job details -->
                            <div class="mb-2.5 job-history">
                                <CandidateJobHistory :data="card?._source?.uid" />
                            </div>
                            <!-- End of candidate job details -->
                            <!-- Start of candidate task history -->
                            <div class="mb-2.5 task-history">
                                <CandidateTaskHistory :tasks="card?._source?.uid" />
                            </div>
                            <!-- End of candidate task history -->
                        </div>
                    </div>
                </template>
            </Modal>
        </div>
    </div>
    <div v-else>
        <CandidateEmptyPage />
    </div>
</template>
<script setup lang="ts">
import moment from 'moment'
import { ref, toRefs, nextTick, defineEmits } from 'vue'
const cardContainer = ref()
const props = defineProps({
    response: {
        type: Object,

        required: true,
    },
})

const emits = defineEmits<{
    /**
     * Select theme event after click on save button
     */
    (event: 'scroll', data: any): void
}>()
const isJsonString = (str: string) => {
    try {
        JSON.parse(str)
    } catch (e) {
        return false
    }
    return true
}
// Handle Scroll event
const handleScroll = async () => {
    // Wait for the next DOM update
    await nextTick()

    const scrollHeight = cardContainer.value.scrollHeight
    const scrollTop = cardContainer.value.scrollTop
    const clientHeight = cardContainer.value.clientHeight
    // Check if the user has scrolled to the bottom
    if (scrollTop + clientHeight + 1 >= scrollHeight) {
        emits('scroll', true)
    }
}
const cards = ref()
const expandedCardIndex = ref(null) // Track the index of the expanded card
const open = ref(false)
const toggleCardDescription = (index) => {
    if (expandedCardIndex.value === index) {
        open.value = true
        expandedCardIndex.value = null // Collapse the card if it's already expanded
    } else {
        expandedCardIndex.value = index // Expand the clicked card
    }
}

const isCardExpanded = (index) => {
    return expandedCardIndex.value === index
}
const { response } = toRefs(props)
const results = response.value
cards.value = results
</script>
<style>
.card-container {
    max-height: 86vh; /* Set a maximum height for the container */
    overflow-y: auto; /* Enable vertical scrolling */
    /* Add any additional styles for the container */
}

/* Additional styles for other elements in your component */
/* ... */
.scrollbar-thin::-webkit-scrollbar {
    width: 5px;
}
.candidates-slideout-header .multiselect-wrapper {
    background-color: rgba(var(--color-bg-lhs), var(--tw-bg-opacity));
    border: 1px solid #fafafa30;
    height: 38px;
}
.candidates-slideout-header .multiselect {
    @apply !h-[38px] !min-h-0 !bg-skin-lhs !border-0;
}
.candidate-skills-list .capitalize.bg-\[\#fafafa\].borer-\[\#f8f8f8\].flex.gap-x-1.items-center.px-2.py-1.rounded-\[4px\].text-\[12px\].text-\[\#475569\] span:last-child {
    color: #475569;
}
.candidates-slideout-header .flex.items-center.gap-6.justify-end .flex.items-center.gap-2\.5 .relative.inline-block svg {
    display: none;
}
.candidates-slideout-header .flex.items-center.gap-6.justify-end .flex.items-center.gap-2\.5 .relative.inline-block span {
    position: initial;
}
.candidates-slideout-header .flex.items-center.gap-6.justify-end .flex.items-center.gap-2\.5 {
    background-color: rgba(var(--color-bg-lhs), var(--tw-bg-opacity));
    border: 1px solid #fafafa30;
    height: 38px;
    padding: 5px 14px;
    border-radius: 5px;
}
.candidates-slideout-header .filter {
    margin-bottom: 0;
}
.candidates-slideout-header .multiselect-wrapper .multiselect-tags {
    margin-left: 5px;
}
.candidates-slideout-header .flex.items-center.w-fit.rounded-md svg,
.candidates-slideout-header .flex.items-center.w-fit.rounded-md i {
    padding: 11px 13px;
}
.candidates-slideout-body .bg-skin-white.mb-3.border-2.rounded-md {
    padding: 16px 0 0 0;
    border: 0;
}
.candidates-slideout-body .p-6.col-span-3 .mb-4 {
    margin-bottom: 0.625rem;
}
.candidates-slideout-body .candidate-analysis .text-neutral-900.mb-1.flex.items-center,
.candidates-slideout-body .candidate-notes .flex.font-semibold.leading-6.text-neutral-900,
.candidates-slideout-body .task-summary-main .font-bold.text-\[1rem\].text-neutral-900 {
    font-size: 16px;
    font-weight: 500;
}
.candidates-slideout-body .candidate-notes {
    border-radius: 0.5rem;
}
.candidates-slideout-body .task-history {
    background: #fff;
    padding: 1rem;
    border-radius: 8px;
    margin-bottom: 10px;
}
.candidates-slideout-body .col-span-3 .mt-4.md\:mt-0.w-full.space-y-0\.5 p.text-neutral-900.capitalize:first-child {
    font-size: 13px;
    margin-bottom: 5px;
}
.candidates-slideout-body .col-span-3 .flex.justify-between dt {
    font-weight: 400;
}
.candidates-slideout-body .col-span-3 .space-y-0\.5.flex.flex-col p {
    color: rgba(var(--color-base), var(--tw-text-opacity));
}
.candidates-slideout-body .cursor-pointer.text-red-500.float-right {
    position: absolute;
    right: 10px;
    top: 4px;
}
.candidates-slideout-header .w-\[60px\].shrink-0.h-\[60px\].rounded-full.overflow-hidden,
.candidates-slideout-header .w-\[60px\].shrink-0.h-\[60px\].rounded-full.overflow-hidden img {
    border-radius: 4px;
}
.candidates-slideout-body .notes-emptystate,
.candidates-slideout-body .tasks-emptystate {
    @apply !max-h-[300px] p-4 space-y-2.5;
}
.candidates-slideout-body .notes-emptystate h3,
.candidates-slideout-body .tasks-emptystate h3 {
    @apply text-sm font-medium;
}
.candidates-slideout-body .notes-emptystate p,
.candidates-slideout-body .tasks-emptystate p {
    @apply text-[13px];
}
.candidates-slideout-body .notes-emptystate img,
.candidates-slideout-body .tasks-emptystate img {
    @apply !h-[140px] p-0;
}
.job-match span {
    position: initial;
    @apply bg-green-50 text-green-500 ring-green-600/20 inline-flex items-center rounded-md px-2 py-1 text-xs font-medium  ring-0 ring-inset border-0;
}
.candidates-slideout-rhs .pt-4 {
    border: 0 !important;
    padding-top: 0 !important;
}
.candidate-video-section .job-feature-card {
    padding: 0;
    border: 0;
}
.employer-comment {
    flex: 0 0 30px;
    max-width: 30px;
    height: 30px;
}
.send-email .relative.shrink-0.h-full.bg-skin-white.border-r.border-skin-base\/20 {
    display: flex;
    align-items: center;
    justify-content: center;
}
.send-email {
    padding-top: 75px;
}
.send-email .relative.shrink-0.h-full.bg-skin-white.border-r.border-skin-base\/20 img {
    height: 450px;
}
.send-email .hidden.lg\:block.w-\[30\%\] {
    width: 40%;
}
.send-email .w-full.lg\:w-\[70\%\].h-full,
.send-email .hidden.lg\:block.w-\[30\%\] .relative.shrink-0.h-full.bg-skin-white.border-r.border-skin-base\/20 {
    background-color: transparent !important;
}
.relative.transform.overflow-hidden.rounded-lg.bg-skin-white.text-left.shadow-xl.transition-all.\[\&_\.pb-\\\[70px\\\]\]\:pb-0.\[\&_\.p-6\]\:p-0.w-full.lg\:w-\[1000px\].\32
    xl\:w-\[1500px\].\[\&_\.p-6\.sm\\\:text-left\.relative\.overflow-auto\]\:overflow-hidden {
    width: 1200px !important;
}
.send-email .w-full.lg\:w-\[70\%\].h-full .border-b.border-skin-base\/20.mb-6.py-3\.5.flex.justify-between.items-center.px-10 {
    background: #171717;
    position: fixed;
    top: 0;
    z-index: 9;
    padding: 16px;
    margin-bottom: 0;
    width: 100%;
    left: 0;
}
.send-email .w-full.lg\:w-\[70\%\].h-full .border-b.border-skin-base\/20.mb-6.py-3\.5.flex.justify-between.items-center.px-10 .text-\[1\.26rem\].font-bold.tracking-tight.text-skin-base {
    color: #fff;
    font-size: 18px;
    font-weight: 600;
    line-height: 22px;
}
.send-email .w-full.lg\:w-\[70\%\].h-full .border-b.border-skin-base\/20.mb-6.py-3\.5.flex.justify-between.items-center.px-10 .text-skin-muted.text-sm {
    color: #fff;
    font-size: 13px;
    font-weight: 400;
}
.send-email
    .w-full.lg\:w-\[70\%\].h-full
    .border-b.border-skin-base\/20.mb-6.py-3\.5.flex.justify-between.items-center.px-10
    .cursor-pointer.fa-regular.fa-xmark.text-base.text-skin-muted.hover\:text-red-500 {
    color: #fff;
    font-size: 22px;
    font-weight: 400;
    top: 3px;
    position: relative;
}
.send-email .relative.h-full.email-component.px-10.mb-8 {
    padding: 20px 16px;
    margin-bottom: 0;
}
.send-email .w-full.space-y-2.mt-\[18px\] .flex.items-center.flex-col.md\:flex-row.gap-5 button:nth-child(2) {
    background: #ffd400 !important;
    border: 1px solid transparent;
}
.send-email .w-full.space-y-2.mt-\[18px\] .flex.items-center.flex-col.md\:flex-row.gap-5 button:nth-child(2):hover,
.send-email .w-full.space-y-2.mt-\[18px\] .flex.items-center.flex-col.md\:flex-row.gap-5 button.px-5.py-2.rounded-lg.bg-skin-white.text-skin-base.hover\:text-skin-primary:hover {
    background: #f7de07 !important;
    border: 1px solid transparent;
    color: #171717;
}
.send-email .w-full.space-y-2.mt-\[18px\] .px-4.py-2.rounded-lg.text-skin-secondary.bg-skin-white.text-sm.border.border-skin-base\/10 {
    display: flex;
    align-items: center;
    color: #171717;
    min-height: 46px;
}
.send-email .w-full.space-y-2.mt-\[18px\] select:focus {
    border-color: rgba(var(--color-base), 0.1);
}
.send-email .w-full.space-y-2.mt-\[18px\] .flex.items-center.flex-col.md\:flex-row.gap-5 button {
    min-height: 46px;
    border: 1px solid rgba(var(--color-base), 0.1);
}
.send-email .w-full.space-y-2.mt-\[18px\] .px-4.py-2.rounded-lg.text-skin-secondary.bg-skin-white.text-sm.border.border-skin-base\/10 .text-sm.font-bold.text-skin-base {
    margin-right: 6px;
}
.send-email .email-component input,
.send-email .email-component .multiselect {
    min-height: 50px;
    border: 1px solid rgba(var(--color-base), 0.1);
}
.send-email .email-component .multiselect .multiselect-tags-search {
    border: 0 !important;
}
.send-email .email-component input:focus,
.send-email .email-component .multiselect:focus {
    border: 1px solid #ffd400 !important;
}
.send-email .email-component .multiselect input:focus {
    border: none !important;
}
.send-email .email-component .multiselect .multiselect-tags {
    margin-top: 0;
    padding-left: 0;
}
.send-email .email-component .multiselect .multiselect-caret {
    background-color: rgba(var(--color-base), 0.6);
    height: 13px;
    margin-right: 0;
}
.send-email .email-component .multiselect .multiselect-tags span {
    background-color: #f5f6f9 !important;
    color: #334151;
    border-color: #e5e5e5 !important;
    padding: 5px;
    font-size: 9px;
    border-radius: 4px;
    margin: 0 6px 0 0;
}
.send-email .email-component .multiselect .multiselect-tags span p {
    font-size: 12px;
}
.send-email .email-component .multiselect .multiselect-tags span p span {
    margin-left: 4px;
}
.send-email .email-component .multiselect .multiselect-tags span p span:hover {
    background-color: #00000010 !important;
}
.send-email .email-component .multiselect .multiselect-tags span p span:hover::before {
    color: #ffd400 !important;
}
.send-email .email-component .multiselect {
    padding: 9px 16px;
}
.send-email .email-component .multiselect input {
    min-height: 30px;
}
.send-email .email-component .ql-container.ql-snow {
    height: 200px;
    overflow-y: auto;
}
.send-email .email-component .track-toggle switch span {
    background-color: #fff;
}
.send-email .email-component .flex.items-center.justify-between.mb-2 {
    margin-bottom: 4px;
}
.send-email .w-full.lg\:w-\[70\%\].bg-skin-white.h-full.flex.flex-col.relative.overflow-auto.max-h-\[calc\(100vh-160px\)\] {
    max-height: calc(100vh - 235px);
}
.send-email label,
.send-email .email-component .track-toggle p,
.send-email .w-full.space-y-2.mt-\[18px\] .px-4.py-2.rounded-lg.text-skin-secondary.bg-skin-white.text-sm.border.border-skin-base\/10 .text-sm.font-bold.text-skin-base {
    color: #171717;
}
.traits-value span {
    font-size: 12px;
    color: #171717;
}

.talent-source-notes .bg-skin-white.border.border-skin-base\/5.mx-auto.overflow-auto {
    padding-bottom: 12px;
    border: 0;
}
.candidates-slideout-body .notes-quill .ql-container.ql-snow {
    max-height: 150px;
    overflow-y: auto;
    height: 100%;
}
.candidates-slideout-body .notes-quill .quill {
    padding: 0px;
    margin: 0 8px 8px 8px;
    border-radius: 4px;
}
.candidates-slideout-body .notes-quill .absolute.top-\[50px\] {
    right: 5px;
    top: 12px;
}
.candidates-slideout-body .notes-quill .flex.flex-col-reverse.border.border-skin-base\/10.text-skin-secondary.relative,
.talent-source-notes .bg-skin-white.items-center {
    border-radius: 4px;
}
.notes-list ul li .flex.group.items-center.text-\[14px\].font-bold.text-skin-secondary.\[\&_\.user-name\]\:text-skin-base\/80 img {
    width: 40px;
    height: 40px;
}
.notes-list ul li .relative.flex.items-center.space-x-3.px-6.py-5.hover\:bg-skin-base\/5 {
    padding: 16px;
}
.notes-list ul li .ml-\[2\.5rem\].flex-1 {
    margin-top: -16px;
    margin-left: 50px;
    color: rgb(107 114 128 / 1);
}
.notes-list ul lir.500apps@gmail.com> .ml-\[2\.5rem\].flex-1 .notes-text .pre::first-letter {
    text-transform: capitalize;
}
.notes-list ul li .text-\[13px\].text-skin-secondary\/70.font-normal.ml-4.flex {
    color: rgb(107 114 128 / 1);
}
.email-component .absolute.right-10 {
    right: 16px;
}
.email-component .absolute.right-10 .relative.group.ml-1\.5 i {
    font-size: 15px;
}
.candidates-filter .flex.border-b.border-dashed.justify-between.py-2\.5.px-4.items-center button {
    border-radius: 4px !important;
}
</style>
