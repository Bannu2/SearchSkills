<template>
    <div class="candidate-analysis border-b border-dashed border-gray-300 mb-4 pb-4">
        <h5 class="text-[15px] font-medium text-neutral-900 mb-3 flex items-center">
            <font-awesome-icon :icon="['far', 'head-side-gear']" class="text-[#3e3e3e] text-[17px] mr-2" />Personality Traits
            <span class="text-[12px] text-gray-500 font-normal ml-[4px] flex items-center">Based on Big5(OCEAN) personality test:</span>
        </h5>

        <ul v-if="traits && traits.length" role="list" class="personality-trails-list flex items-center flex-wrap gap-1.5 text-[13px]">
            <li v-for="personality in traits" :key="personality" class="capitalize border border-gray-200 flex gap-x-1 items-center px-2 py-1 rounded-[4px]">
                <div class="text-neutral-900 flex items-center gap-x-2">
                    <span class="font-normal text-[12px] text-[#475569] mr-[2px]">{{ personality?.key }} </span>
                    <div class="traits-value">
                        <span class="inline-flex items-center rounded-[5px] px-2 py-1 text-xs font-medium">{{ personality?.value }}</span>
                    </div>
                </div>
            </li>
        </ul>
        <div v-else class="my-5">
            <div class="flex flex-col items-center justify-center">
                <img src="https://assets.infinity-api.net/emc2/stark-recruiter/empty-state/no-results-found.svg" alt="" class="w-auto h-[120px] mx-auto object-cover" />
                <span class="font-medium text-sm text-neutral-900">No Traits Found</span>
            </div>
        </div>
    </div>
</template>
<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { useAuthLazyFetch } from '#imports'

const traits = ref()

interface Props {
    candidateId: String
}
const props = withDefaults(defineProps<Props>(), {})

onMounted(() => {
    setTimeout(() => {
        getTraits()
    }, 0)
})

const getTraits = async () => {
    const { data: response } = await useAuthLazyFetch(`https://api.stark.ai/prod/orm/responses/candidates/${props.candidateId}/personality?offset=0&limit=100&sort_column=id&sort_direction=desc`, {})
    traits.value = JSON.parse(response.value[0]?.recommendations)
}
</script>
