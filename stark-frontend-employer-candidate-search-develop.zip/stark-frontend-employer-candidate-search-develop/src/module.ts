import { fileURLToPath } from 'url'
import { addComponentsDir, defineNuxtModule, createResolver, installModule, addImportsDir } from '@nuxt/kit'

// Module options TypeScript interface definition
export interface ModuleOptions {}

export default defineNuxtModule<ModuleOptions>({
    meta: {
        name: 'stark-frontend-plugin-candidate-search',
        configKey: 'StarkFrontendPluginCandidateSearch',
    },
    // Default configuration options of the Nuxt module
    defaults: {},

    setup: async (_options, nuxt: any) => {
        // Get the directory path for the runtime files
        const runtimeDir = fileURLToPath(new URL('./runtime', import.meta.url))

        // Create a resolver for importing files
        const { resolve, resolvePath } = createResolver(import.meta.url)

        // Add the runtime directory to the transpile option in Nuxt build configuration
        nuxt.options.build.transpile.push(runtimeDir)

        // Components will be extended
        addComponentsDir({
            path: resolve(runtimeDir, 'components'),
            prefix: 'Candidate', // Prefix to components if needed
        })

        // Add data directory to Nuxt project
        addImportsDir(resolve(runtimeDir, 'data'))

        // Add alias for vueuse/core package which is not able to auto import
        const vueCore = await resolvePath('@vueuse/core')
        nuxt.options.alias.vueCore = vueCore

        // Add alias for @vueform/multiselect package which is not able to auto import
        const Multiselect = await resolvePath('@vueform/multiselect')
        nuxt.options.alias.Multiselect = Multiselect

        // Add content paths of plugin files to tailwind config
        // @ts-expect-error nocheck
        nuxt.hook('tailwindcss:config', (tailwindConfig) => {
            const resourcePaths = (srcDir: string) => [
                `${srcDir}/components/**/*.{js,vue,ts}`,
                `${srcDir}/pages/**/*.{vue,ts,js}`,
                `${srcDir}/composables/**/*.{js,ts,json}`,
                `${srcDir}/stores/**/*.{js,ts,json}`,
                `${srcDir}/utils/**/*.{js,ts,json}`,
            ]
            const contentPaths = resourcePaths(runtimeDir)
            tailwindConfig.content.push(...contentPaths)
        })
        // Add data to current module using 'installModule' api
        const nuxtConfigModules = nuxt.options.modules
        addImportsDir(resolve(runtimeDir, 'data'))

        // Add plugins to using composables
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-composables')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-composables'), { autoImports: true })
        }

        // Add plugins to using auth
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-auth')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-auth'), { autoImports: true })
        }
        // Add plugins to using form
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-form')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-form'), { autoImports: true })
        }
        if (!nuxtConfigModules.includes('@owfis/stark-frontend-plugin-candidate-core-data-dev')) {
            installModule(await resolvePath('@owfis/stark-frontend-plugin-candidate-core-data-dev'), { autoImports: true })
        }
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-notes')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-notes'), { autoImports: true })
        }
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-email-component')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-email-component'), { autoImports: true })
        }
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-telephony')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-telephony'), { autoImports: true })
        }
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-ai-prompt')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-ai-prompt'), { autoImports: true })
        }
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-task-summary')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-task-summary'), { autoImports: true })
        }
        if (!nuxtConfigModules.includes('@bub-io/frontend-plugin-tasks')) {
            installModule(await resolvePath('@bub-io/frontend-plugin-tasks'), { autoImports: true })
        }
    },
})
