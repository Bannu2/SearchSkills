# Frontend Plugin Sample Component
